export const siteConfig = {
  name: "Rumah Khitan Al-Asyraf",
  tagline: "Pusat Khitan Modern Terpercaya di Situbondo",
  description:
    "Rumah Khitan Al-Asyraf - Pusat Khitan Modern Terpercaya di Situbondo. Metode Lem, Cincin, dan Jahit dengan bius tanpa suntik. Hadiah & kontrol gratis.",
  whatsapp: "6282257089393",
  whatsappDisplay: "0822-5708-9393",
  address: "Belakang Toko Ringgit Lama, Ke utara Taman Kota Asembagus, Situbondo",
  addressShort: "Asembagus, Situbondo",
  email: "info@al-asyr-khitan.com",
  logo: "/images/logo.png",
  mapEmbed:
    "https://maps.google.com/maps?q=-7.7487442,114.2177028&z=17&output=embed",
  mapLink:
    "https://www.google.com/maps/place/7%C2%B044'55.5%22S+114%C2%B013'03.7%22E/@-7.7489203,114.2153587,17.05z/data=!4m4!3m3!8m2!3d-7.7487442!4d114.2177028",
  hours: "Setiap Hari, 08.00 - 20.00 WIB",
};

export type NavLink = { label: string; href: string };

export const navLinks: NavLink[] = [
  { label: "Beranda", href: "#beranda" },
  { label: "Keunggulan", href: "#keunggulan" },
  { label: "Metode & Harga", href: "#metode" },
  { label: "Infus Vitamin", href: "#infus" },
  { label: "Proses", href: "#proses" },
  { label: "Galeri", href: "#galeri" },
  { label: "Fasilitas", href: "#fasilitas" },
  { label: "Testimoni", href: "#testimoni" },
  { label: "Ulasan", href: "#ulasan" },
  { label: "FAQ", href: "#faq" },
  { label: "Lokasi", href: "#lokasi" },
];

export type Method = {
  id: string;
  name: string;
  tagline: string;
  price: number;
  priceLabel: string;
  features: string[];
  popular?: boolean;
  premium?: boolean;
  badge?: string;
};

export const methods: Method[] = [
  {
    id: "jahit",
    name: "Metode Jahit",
    tagline: "Metode konvensional dengan penyempurnaan teknik modern.",
    price: 750000,
    priceLabel: "Rp 750.000",
    features: ["Bius tanpa suntik (Free Needle)", "Hasil rapi & estetis"],
  },
  {
    id: "cincin",
    name: "Metode Cincin / Ring",
    tagline: "Tanpa jahit, tanpa perban, hasil sangat presisi.",
    price: 1150000,
    priceLabel: "Rp 1.150.000",
    features: [
      "Bius tanpa suntik",
      "Tanpa Jahit & Tanpa Perban",
      "Bisa langsung mandi & beraktivitas",
    ],
    popular: true,
    badge: "Terpopuler",
  },
  {
    id: "lem",
    name: "Metode Lem",
    tagline: "Inovasi terbaru menggunakan skin adhesive khusus medis.",
    price: 1200000,
    priceLabel: "Rp 1.200.000",
    features: [
      "Bius tanpa suntik",
      "Tanpa alat menempel (Cincin)",
      "Penyembuhan relatif lebih cepat & nyaman",
    ],
    premium: true,
    badge: "Premium",
  },
];

export type InfusPackage = {
  id: string;
  name: string;
  tagline: string;
  price: number;
  priceLabel: string;
  duration: string;
  features: string[];
  popular?: boolean;
  badge?: string;
  icon: string;
  color: string;
};

export const infusPackages: InfusPackage[] = [
  {
    id: "vitamin-c",
    name: "Infus Vitamin C",
    tagline: "Meningkatkan imunitas & menjaga kesehatan kulit.",
    price: 250000,
    priceLabel: "Rp 250.000",
    duration: "± 30 menit",
    features: [
      "Vitamin C dosis standar (1-3 gram)",
      "Diberikan tenaga medis bersertifikat",
      "Alat steril sekali pakai",
      "Konsultasi singkat sebelum tindakan",
    ],
    icon: "ShieldPlus",
    color: "amber",
  },
  {
    id: "vitamin-c-high",
    name: "Infus Vitamin C High Dose",
    tagline: "Imunitas optimal, pemulihan cepat & antioksidan tinggi.",
    price: 450000,
    priceLabel: "Rp 450.000",
    duration: "± 45 menit",
    features: [
      "Vitamin C dosis tinggi (5-10 gram)",
      "Pemulihan setelah sakit / kelelahan",
      "Meningkatkan stamina & imunitas",
      "Perawatan oleh perawat profesional",
      "Konsultasi & monitoring tindakan",
    ],
    popular: true,
    badge: "Terpopuler",
    icon: "ShieldPlus",
    color: "emerald",
  },
  {
    id: "cocktail",
    name: "Infus Vitamin Cocktail",
    tagline: "Kombinasi multivitamin untuk energi & vitalitas harian.",
    price: 550000,
    priceLabel: "Rp 550.000",
    duration: "± 45-60 menit",
    features: [
      "Kombinasi Vitamin C + B Complex + Mineral",
      "Boost energi & metabolisme",
      "Cocok untuk sibuk & kurang tidur",
      "Monitoring kondisi selama pemasangan",
    ],
    icon: "FlaskConical",
    color: "teal",
  },
  {
    id: "imun-booster",
    name: "Imun Booster Pack",
    tagline: "Paket lengkap untuk daya tahan tubuh maksimal.",
    price: 750000,
    priceLabel: "Rp 750.000",
    duration: "± 60 menit",
    features: [
      "Vitamin C High Dose + B Complex + Zinc",
      "Sangat cocok pasca sakit / kurang gizi",
      "Pemeriksaan tensi & kondisi umum",
      "Konsultasi medis mendalam",
      "Garansi pelayanan & kontrol gratis",
    ],
    badge: "Paket Lengkap",
    icon: "HeartPulse",
    color: "rose",
  },
];

export const infusBenefits: { title: string; description: string; icon: string }[] = [
  {
    title: "Dipasang di Rumah",
    description:
      "Tenaga medis datang kerumah Anda — tidak perlu antri, nyaman di tempat istirahat sendiri.",
    icon: "Home",
  },
  {
    title: "Tenaga Medis Bersertifikat",
    description:
      "Dipasang perawat/profesional medis terlatih dengan prosedur steril & aman.",
    icon: "BadgeCheck",
  },
  {
    title: "Alat Steril Sekali Pakai",
    description:
      "Seluruh alat infus baru dan steril, mencegah risiko infeksi atau kontaminasi.",
    icon: "ShieldCheck",
  },
  {
    title: "Harga Terjangkau",
    description:
      "Mulai Rp 250.000, transparan tanpa biaya tersembunyi. Bayar sesuai paket.",
    icon: "Wallet",
  },
];

export type Facility = {
  name: string;
  description: string;
  image: string;
};

export const facilities: Facility[] = [
  {
    name: "Mobil Remot",
    description: "Mainan mobil remot seru untuk jagoan",
    image:
      "https://images.pexels.com/photos/9227215/pexels-photo-9227215.jpeg?auto=compress&cs=tinysrgb&h=400&w=400",
  },
  {
    name: "Celana Khitan",
    description: "Celana khusus nyaman pasca khitan",
    image:
      "https://images.pexels.com/photos/8460125/pexels-photo-8460125.jpeg?auto=compress&cs=tinysrgb&h=400&w=400",
  },
  {
    name: "Sertifikat",
    description: "Sertifikat resmi khitan",
    image:
      "https://images.pexels.com/photos/8177922/pexels-photo-8177922.jpeg?auto=compress&cs=tinysrgb&h=400&w=400",
  },
  {
    name: "Tas Sunat",
    description: "Tas khusus jagoan khitan",
    image:
      "https://images.pexels.com/photos/37580640/pexels-photo-37580640.jpeg?auto=compress&cs=tinysrgb&h=400&w=400",
  },
  {
    name: "Obat Rawat Jalan",
    description: "Obat perawatan pasca khitan",
    image:
      "https://images.pexels.com/photos/7034123/pexels-photo-7034123.jpeg?auto=compress&cs=tinysrgb&h=400&w=400",
  },
  {
    name: "Kontrol Gratis",
    description: "Kontrol & konsultasi gratis hingga sembuh",
    image:
      "https://images.pexels.com/photos/8460125/pexels-photo-8460125.jpeg?auto=compress&cs=tinysrgb&h=400&w=400",
  },
];

export type GalleryItem = {
  title: string;
  description: string;
  tag: string;
  image: string;
};

export const galleryItems: GalleryItem[] = [
  {
    title: "Standar Medis Higienis",
    description:
      "Peralatan medis steril sekali pakai dan ruangan ber-AC yang nyaman untuk anak.",
    tag: "Ruang Tindakan Steril",
    image:
      "https://images.pexels.com/photos/7789620/pexels-photo-7789620.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
  {
    title: "Tanpa Trauma & Ceria",
    description:
      "Berkat metode bius tanpa suntik, anak tetap tenang dan gembira selama tindakan.",
    tag: "Senyum Bahagia",
    image:
      "https://images.pexels.com/photos/18054416/pexels-photo-18054416.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
  {
    title: "Hadiah Mobil Remot & Tas",
    description:
      "Setiap jagoan langsung membawa pulang hadiah menarik setelah khitan selesai.",
    tag: "Bonus Spesial",
    image:
      "https://images.pexels.com/photos/9227215/pexels-photo-9227215.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
  {
    title: "Proses Cepat & Aman",
    description:
      "Tindakan dilakukan tenaga medis berpengalaman dengan prosedur steril.",
    tag: "Tindakan Medis",
    image:
      "https://images.pexels.com/photos/7034123/pexels-photo-7034123.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
  {
    title: "Suasana Nyaman",
    description:
      "Ruang tunggu yang bersih dan nyaman untuk keluarga jagoan.",
    tag: "Ruang Tunggu",
    image:
      "https://images.pexels.com/photos/8177922/pexels-photo-8177922.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
  {
    title: "Perawatan Pasca Khitan",
    description:
      "Panduan lengkap perawatan di rumah dan obat gratis untuk penyembuhan optimal.",
    tag: "Perawatan",
    image:
      "https://images.pexels.com/photos/8460125/pexels-photo-8460125.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
];

export type Testimonial = {
  name: string;
  role: string;
  message: string;
  initial: string;
  rating: number;
};

export const testimonials: Testimonial[] = [
  {
    name: "Bapak Sutrisno",
    role: "Orang tua jagoan",
    message:
      "Anak saya tidak nangis sama pas khitan! Metode cincinnya cepat dan rapi. Besoknya sudah jalan-jalan lagi. Recommended banget!",
    initial: "S",
    rating: 5,
  },
  {
    name: "Ibu Fatimah",
    role: "Orang tua jagoan",
    message:
      "Pelayanannya ramah, tempatnya bersih. Anak saya diberi hadiah mobil remot, langsung senang lupa khitan. Terima kasih Al-Asyraf!",
    initial: "F",
    rating: 5,
  },
  {
    name: "Bapak Hendra",
    role: "Orang tua jagoan",
    message:
      "Awalnya khawatir anak saya takut, tapi dengan bius tanpa suntik, dia santai saja. Hasilnya juga sangat rapi. Mantap!",
    initial: "H",
    rating: 5,
  },
  {
    name: "Ibu Aisyah",
    role: "Orang tua jagoan",
    message:
      "Layanan home service-nya sangat membantu. Dokternya sabar dan profesional. Anak saya nyaman di rumah sendiri.",
    initial: "A",
    rating: 5,
  },
  {
    name: "Bapak Joko",
    role: "Orang tua jagoan",
    message:
      "Harga sesuai kualitas. Fasilitas bonus lengkap dari tas sampai sertifikat. Kontrol gratis sampai sembuh. Puas!",
    initial: "J",
    rating: 5,
  },
  {
    name: "Ibu Ratna",
    role: "Orang tua jagoan",
    message:
      "Klinik recommended di Situbondo. Suami sayasampai direkomendasikan ke semua tetangga. Anak happy, ortu tenang.",
    initial: "R",
    rating: 5,
  },
];

export type Faq = { question: string; answer: string };

export const faqs: Faq[] = [
  {
    question: "Berapa usia minimal anak untuk khitan di Al-Asyraf?",
    answer:
      "Kami melayani khitan untuk anak usia 2 tahun hingga dewasa. Untuk anak usia di bawah 2 tahun, silakan konsultasikan terlebih dahulu via WhatsApp kami.",
  },
  {
    question: "Apakah anak perlu puasa sebelum khitan?",
    answer:
      "Tidak perlu puasa. Justru kami menyarankan anak sudah makan sebelum tindakan agar tidak lemas. Pastikan anak dalam kondisi sehat.",
  },
  {
    question: "Berapa lama proses khitan modern?",
    answer:
      "Proses tindakan sendiri relatif cepat, sekitar 10-15 menit termasuk persiapan. Total di klinik sekitar 30-45 menit.",
  },
  {
    question: "Apakah ada layanan khitan di rumah (home service)?",
    answer:
      "Ya, kami menyediakan layanan panggilan ke rumah Anda dengan tambahan biaya Rp 50.000 (menyesuaikan jarak tempuh). Hubungi WhatsApp untuk jadwal.",
  },
  {
    question: "Berapa lama proses penyembuhan?",
    answer:
      "Metode Cincin dan Lem biasanya 7-10 hari. Metode Jahit sekitar 10-14 hari. Kontrol pasca khitan gratis sampai sembuh total.",
  },
  {
    question: "Metode apa yang paling cocok untuk anak saya?",
    answer:
      "Setiap metode memiliki keunggulan masing-masing. Metode Cincin adalah yang terpopuler karena tanpa jahit dan tanpa perban. Konsultasikan via WhatsApp untuk rekomendasi sesuai kondisi anak Anda.",
  },
  {
    question: "Apakah ada layanan infus vitamin homecare?",
    answer:
      "Ya! Kami menyediakan layanan pemasangan infus vitamin langsung di rumah Anda (Asembagus & sekitarnya). Pilih dari 4 paket: Vitamin C (Rp 250.000), Vitamin C High Dose (Rp 450.000), Vitamin Cocktail (Rp 550.000), atau Imun Booster Pack (Rp 750.000). Semua dipasang tenaga medis bersertifikat dengan alat steril sekali pakai. Pesan via website atau WhatsApp.",
  },
  {
    question: "Apakah bius tanpa suntik benar-benar tanpa rasa sakit?",
    answer:
      "Metode Free Needle Injection kami menggunakan teknologi semprot bius bertekanan sehingga anak tidak merasakan tusukan jarum. Rasa sakit sangat minim, anak tetap nyaman.",
  },
  {
    question: "Bagaimana cara pendaftaran online?",
    answer:
      "Anda bisa mendaftar online melalui tombol 'Daftar Online' di website ini, isi formulir pendaftaran, lalu tim kami akan menghubungi via WhatsApp untuk konfirmasi jadwal.",
  },
];

export type ProcessStep = {
  number: number;
  title: string;
  description: string;
  icon: string;
};

export const processSteps: ProcessStep[] = [
  {
    number: 1,
    title: "Konsultasi & Pendaftaran",
    description:
      "Hubungi via WhatsApp atau daftar online. Tim kami akan membantu memilih metode yang sesuai.",
    icon: "CalendarCheck",
  },
  {
    number: 2,
    title: "Persiapan & Bius Tanpa Suntik",
    description:
      "Anak dipersiapkan dengan teknologi Free Needle Injection, nyaman tanpa rasa takut jarum.",
    icon: "Syringe",
  },
  {
    number: 3,
    title: "Tindakan Khitan",
    description:
      "Proses cepat 10-15 menit oleh tenaga medis berpengalaman dengan alat steril sekali pakai.",
    icon: "Stethoscope",
  },
  {
    number: 4,
    title: "Hadiah & Pulang",
    description:
      "Jagoan menerima hadiah mobil remot, tas, sertifikat, dan obat perawatan gratis.",
    icon: "Gift",
  },
  {
    number: 5,
    title: "Kontrol Gratis",
    description:
      "Konsultasi & kontrol pasca khitan gratis sampai jagoan benar-benar sembuh total.",
    icon: "HeartPulse",
  },
];

export type Advantage = {
  title: string;
  description: string;
  icon: string;
  color: string;
};

export const advantages: Advantage[] = [
  {
    title: "Bius Tanpa Suntik",
    description:
      "Menggunakan teknologi modern Free Needle Injection, lebih nyaman dan mengurangi rasa takut pada anak.",
    icon: "Syringe",
    color: "emerald",
  },
  {
    title: "Tanpa Jahit & Perban",
    description:
      "Metode tertentu (Lem/Cincin) tidak memerlukan jahitan konvensional, meminimalisir rasa sakit pasca khitan.",
    icon: "Bandage",
    color: "amber",
  },
  {
    title: "Bisa Langsung Aktivitas",
    description:
      "Proses penyembuhan lebih cepat, anak bisa langsung mandi dan beraktivitas normal seperti biasa.",
    icon: "Activity",
    color: "yellow",
  },
  {
    title: "Kontrol Gratis",
    description:
      "Layanan kontrol dan konsultasi pasca khitan gratis sampai anak Anda benar-benar sembuh.",
    icon: "HeartHandshake",
    color: "teal",
  },
];

export const stats = [
  { value: 1500, suffix: "+", label: "Jagoan Khitan" },
  { value: 8, suffix: " Tahun", label: "Pengalaman" },
  { value: 100, suffix: "%", label: "Kepuasan" },
  { value: 3, suffix: "", label: "Metode Modern" },
];

export function buildWhatsAppUrl(message: string) {
  return `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(message)}`;
}

export const defaultWaMessage =
  "Assalamualaikum, saya ingin berkonsultasi tentang layanan khitan di Rumah Khitan Al-Asyraf.";
