"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { motion } from "framer-motion";
import { HelpCircle, MessageCircle } from "lucide-react";
import { faqs, buildWhatsAppUrl } from "@/lib/site";
import { SectionHeading } from "./keunggulan";

export function Faq() {
  return (
    <section
      id="faq"
      className="py-20 md:py-28 bg-background px-4 scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 gradient-mesh opacity-40 pointer-events-none" />
      <div className="max-w-3xl mx-auto relative z-10">
        <SectionHeading
          eyebrow="Bantuan"
          title="Pertanyaan yang Sering Diajukan"
          subtitle="Temukan jawaban atas pertanyaan umum seputar layanan khitan di Al-Asyraf."
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <Accordion
            type="single"
            collapsible
            defaultValue="item-0"
            className="space-y-3"
          >
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="bg-card rounded-3xl border border-border card-modern px-5 [&[data-state=open]]:border-brand/40 [&[data-state=open]]:shadow-soft transition-all"
              >
                <AccordionTrigger className="text-left hover:no-underline py-5">
                  <span className="font-semibold text-foreground text-sm sm:text-base pr-4 flex items-start gap-2.5">
                    <HelpCircle className="h-5 w-5 text-brand flex-shrink-0 mt-0.5" />
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5 pl-9 text-pretty">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>

        <div className="mt-8 text-center">
          <p className="text-muted-foreground text-sm mb-3">
            Masih ada pertanyaan lain?
          </p>
          <a
            href={buildWhatsAppUrl(
              "Halo, saya ingin bertanya seputar layanan khitan di Al-Asyraf."
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-6 py-3 rounded-2xl shadow-md transition hover:-translate-y-0.5"
          >
            <MessageCircle className="h-5 w-5" />
            Tanya via WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
