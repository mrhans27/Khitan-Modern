"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Upload,
  Lock,
  Loader2,
  Image as ImageIcon,
  Video as VideoIcon,
  Trash2,
  Check,
  X,
  Star,
  Plus,
  ExternalLink,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type GalleryItem = {
  id: string;
  title: string;
  description: string | null;
  tag: string | null;
  type: string;
  url: string;
  thumbUrl: string | null;
  category: string;
  createdAt: string;
};

type ReviewItem = {
  id: string;
  name: string;
  role: string;
  rating: number;
  comment: string;
  service: string | null;
  approved: boolean;
  createdAt: string;
};

const ADMIN_KEY_STORAGE = "al-asyraf-admin-key";

export function AdminPanel({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [authed, setAuthed] = React.useState(false);
  const [keyInput, setKeyInput] = React.useState("");
  const [authing, setAuthing] = React.useState(false);
  const { toast } = useToast();

  // Check stored key on open
  React.useEffect(() => {
    if (open) {
      const stored = sessionStorage.getItem(ADMIN_KEY_STORAGE);
      if (stored) {
        setKeyInput(stored);
        setAuthed(true);
      }
    }
  }, [open]);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthing(true);
    // Test the key against admin/reviews endpoint
    fetch("/api/admin/reviews", {
      headers: { authorization: `Bearer ${keyInput}` },
    })
      .then((r) => {
        if (r.ok) {
          sessionStorage.setItem(ADMIN_KEY_STORAGE, keyInput);
          setAuthed(true);
          toast({ title: "Login admin berhasil" });
        } else {
          toast({
            title: "Kunci admin salah",
            description: "Periksa kembali kunci admin Anda.",
            variant: "destructive",
          });
        }
      })
      .catch(() => {
        toast({
          title: "Gagal memverifikasi",
          variant: "destructive",
        });
      })
      .finally(() => setAuthing(false));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl max-h-[92vh] overflow-y-auto p-0 gap-0">
        <div className="bg-gradient-to-br from-brand to-brand/85 text-white p-6 rounded-t-xl">
          <DialogHeader className="p-0 space-y-1 text-left">
            <DialogTitle className="flex items-center gap-2 text-xl text-white">
              <Lock className="h-5 w-5 text-gold" />
              Panel Admin
            </DialogTitle>
            <DialogDescription className="text-white/80 text-sm">
              Kelola galeri (upload foto/video) dan persetujuan ulasan pelanggan.
            </DialogDescription>
          </DialogHeader>
        </div>

        {authed ? (
          <AdminDashboard adminKey={keyInput} />
        ) : (
          <form onSubmit={handleAuth} className="p-6 space-y-4">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium flex items-center gap-1.5">
                <Lock className="h-4 w-4 text-brand" /> Kunci Admin
              </Label>
              <Input
                type="password"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder="Masukkan kunci admin"
                autoFocus
              />
              <p className="text-xs text-muted-foreground">
                Kunci admin diperlukan untuk mengelola galeri & ulasan.
              </p>
            </div>
            <Button
              type="submit"
              disabled={authing || !keyInput.trim()}
              className="w-full bg-brand hover:bg-brand/90"
            >
              {authing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Memverifikasi...
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4" /> Masuk
                </>
              )}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

function AdminDashboard({ adminKey }: { adminKey: string }) {
  const [tab, setTab] = React.useState<"gallery" | "reviews">("gallery");

  return (
    <div className="p-6">
      {/* Tabs */}
      <div className="inline-flex p-1.5 bg-muted rounded-2xl border border-border mb-6">
        <button
          type="button"
          onClick={() => setTab("gallery")}
          className={cn(
            "px-5 py-2.5 rounded-xl font-semibold transition flex items-center gap-2 text-sm",
            tab === "gallery"
              ? "bg-card text-brand shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          <ImageIcon className="h-4 w-4" /> Galeri
        </button>
        <button
          type="button"
          onClick={() => setTab("reviews")}
          className={cn(
            "px-5 py-2.5 rounded-xl font-semibold transition flex items-center gap-2 text-sm",
            tab === "reviews"
              ? "bg-card text-brand shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Star className="h-4 w-4" /> Ulasan
        </button>
      </div>

      {tab === "gallery" ? (
        <GalleryManager adminKey={adminKey} />
      ) : (
        <ReviewsManager adminKey={adminKey} />
      )}
    </div>
  );
}

function GalleryManager({ adminKey }: { adminKey: string }) {
  const [items, setItems] = React.useState<GalleryItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const { toast } = useToast();

  // upload form
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [tag, setTag] = React.useState("");
  const [type, setType] = React.useState<"photo" | "video">("photo");
  const [category, setCategory] = React.useState<"galeri" | "dokumentasi">(
    "galeri"
  );
  const [file, setFile] = React.useState<File | null>(null);
  const [thumbFile, setThumbFile] = React.useState<File | null>(null);
  const [uploading, setUploading] = React.useState(false);
  const [previewUrl, setPreviewUrl] = React.useState<string | null>(null);
  const [thumbPreview, setThumbPreview] = React.useState<string | null>(null);

  const load = React.useCallback(() => {
    setLoading(true);
    fetch("/api/admin/gallery", {
      headers: { authorization: `Bearer ${adminKey}` },
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setItems(d.items);
      })
      .finally(() => setLoading(false));
  }, [adminKey]);

  React.useEffect(() => {
    load();
  }, [load]);

  const onFile = (f: File | null) => {
    setFile(f);
    if (f) {
      setPreviewUrl(URL.createObjectURL(f));
      // auto-detect type from extension
      const name = f.name.toLowerCase();
      if (/\.(mp4|webm|mov|m4v)$/.test(name)) setType("video");
      else setType("photo");
    } else {
      setPreviewUrl(null);
    }
  };

  const onThumb = (f: File | null) => {
    setThumbFile(f);
    setThumbPreview(f ? URL.createObjectURL(f) : null);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (uploading) return;
    if (!file) {
      toast({
        title: "File wajib diupload",
        description: "Pilih foto atau video terlebih dahulu.",
        variant: "destructive",
      });
      return;
    }
    if (!title.trim()) {
      toast({ title: "Judul wajib diisi", variant: "destructive" });
      return;
    }

    setUploading(true);
    try {
      // 1. Upload main file
      const fd = new FormData();
      fd.append("file", file);
      const upRes = await fetch("/api/admin/upload", {
        method: "POST",
        headers: { authorization: `Bearer ${adminKey}` },
        body: fd,
      });
      const upData = await upRes.json();
      if (!upRes.ok || !upData.ok) throw new Error(upData.error || "Upload gagal");

      // 2. Upload thumbnail if provided (for videos)
      let thumbUrl = "";
      if (thumbFile) {
        const fd2 = new FormData();
        fd2.append("file", thumbFile);
        const tRes = await fetch("/api/admin/upload", {
          method: "POST",
          headers: { authorization: `Bearer ${adminKey}` },
          body: fd2,
        });
        const tData = await tRes.json();
        if (tRes.ok && tData.ok) thumbUrl = tData.url;
      }

      // 3. Create gallery entry
      const res = await fetch("/api/admin/gallery", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          authorization: `Bearer ${adminKey}`,
        },
        body: JSON.stringify({
          title,
          description,
          tag,
          type: upData.type,
          url: upData.url,
          thumbUrl: thumbUrl || null,
          category,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Gagal simpan");

      toast({ title: "Media berhasil ditambahkan!" });
      // Reset
      setTitle("");
      setDescription("");
      setTag("");
      setFile(null);
      setThumbFile(null);
      setPreviewUrl(null);
      setThumbPreview(null);
      load();
    } catch (e) {
      toast({
        title: "Gagal upload",
        description: e instanceof Error ? e.message : "Terjadi kesalahan",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const del = async (id: string) => {
    if (!confirm("Hapus media ini? File juga akan dihapus.")) return;
    try {
      const res = await fetch(`/api/admin/gallery?id=${id}`, {
        method: "DELETE",
        headers: { authorization: `Bearer ${adminKey}` },
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error);
      toast({ title: "Media dihapus" });
      load();
    } catch (e) {
      toast({
        title: "Gagal hapus",
        description: e instanceof Error ? e.message : "",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload form */}
      <form onSubmit={submit} className="bg-muted/40 rounded-2xl p-5 border border-border space-y-4">
        <h3 className="font-bold text-foreground flex items-center gap-2">
          <Plus className="h-5 w-5 text-brand" /> Upload Media Baru
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Judul *</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Cth: Jagoan Senyum Bahagia"
              maxLength={120}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Tag (opsional)</Label>
            <Input
              value={tag}
              onChange={(e) => setTag(e.target.value)}
              placeholder="Cth: Senyum Bahagia"
              maxLength={60}
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-sm font-medium">Deskripsi (opsional)</Label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Deskripsi singkat..."
            rows={2}
            maxLength={400}
            className="resize-none"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          <span className="text-sm font-medium self-center mr-2">Kategori:</span>
          {(["galeri", "dokumentasi"] as const).map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              className={cn(
                "px-3 py-1.5 rounded-xl text-sm font-medium transition capitalize",
                category === c
                  ? "bg-brand text-brand-foreground"
                  : "bg-card border border-border hover:bg-muted"
              )}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-sm font-medium flex items-center gap-1.5">
              {type === "video" ? (
                <VideoIcon className="h-4 w-4 text-brand" />
              ) : (
                <ImageIcon className="h-4 w-4 text-brand" />
              )}
              File {type === "video" ? "Video" : "Foto"} *
            </Label>
            <input
              type="file"
              accept={
                type === "video"
                  ? "video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov,.m4v"
                  : "image/jpeg,image/png,image/webp,image/gif,.jpg,.jpeg,.png,.webp,.gif"
              }
              onChange={(e) => onFile(e.target.files?.[0] ?? null)}
              className="block w-full text-sm text-muted-foreground file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:bg-brand file:text-brand-foreground file:font-semibold file:cursor-pointer hover:file:bg-brand/90 cursor-pointer"
            />
            {previewUrl && type === "photo" && (
              <div className="relative h-32 rounded-xl overflow-hidden border border-border">
                <img
                  src={previewUrl}
                  alt="preview"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            {previewUrl && type === "video" && (
              <video
                src={previewUrl}
                className="h-32 rounded-xl border border-border"
                controls
              />
            )}
          </div>

          {type === "video" && (
            <div className="space-y-1.5">
              <Label className="text-sm font-medium flex items-center gap-1.5">
                <ImageIcon className="h-4 w-4 text-brand" /> Thumbnail (opsional)
              </Label>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
                onChange={(e) => onThumb(e.target.files?.[0] ?? null)}
                className="block w-full text-sm text-muted-foreground file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:bg-brand file:text-brand-foreground file:font-semibold file:cursor-pointer hover:file:bg-brand/90 cursor-pointer"
              />
              {thumbPreview && (
                <div className="relative h-32 rounded-xl overflow-hidden border border-border">
                  <img
                    src={thumbPreview}
                    alt="thumb"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          )}
        </div>

        <Button
          type="submit"
          disabled={uploading}
          className="bg-brand hover:bg-brand/90"
        >
          {uploading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Mengupload...
            </>
          ) : (
            <>
              <Upload className="h-4 w-4" /> Upload & Tambahkan
            </>
          )}
        </Button>
      </form>

      {/* Existing media list */}
      <div>
        <h3 className="font-bold text-foreground mb-3">
          Media Tersimpan ({items.length})
        </h3>
        {loading ? (
          <div className="text-center py-8 text-muted-foreground">
            <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
            Memuat...
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground bg-muted/40 rounded-2xl border border-border">
            <ImageIcon className="h-8 w-8 mx-auto mb-2 opacity-50" />
            Belum ada media. Upload di atas.
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {items.map((item) => (
              <div
                key={item.id}
                className="bg-card rounded-2xl border border-border overflow-hidden"
              >
                <div className="h-28 relative bg-muted">
                  {item.type === "video" ? (
                    <video
                      src={item.url}
                      className="w-full h-full object-cover"
                      muted
                    />
                  ) : (
                    <img
                      src={item.url}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                  )}
                  <span className="absolute top-2 left-2 bg-black/70 text-white text-[10px] px-2 py-0.5 rounded-full">
                    {item.type === "video" ? "VIDEO" : "FOTO"}
                  </span>
                  <span className="absolute top-2 right-2 bg-brand text-brand-foreground text-[10px] px-2 py-0.5 rounded-full capitalize">
                    {item.category}
                  </span>
                </div>
                <div className="p-2.5">
                  <p className="font-semibold text-xs text-foreground truncate">
                    {item.title}
                  </p>
                  <div className="flex items-center justify-between mt-2">
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-brand"
                      aria-label="Buka file"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                    <button
                      type="button"
                      onClick={() => del(item.id)}
                      className="text-destructive hover:bg-destructive/10 p-1 rounded-lg transition"
                      aria-label="Hapus"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ReviewsManager({ adminKey }: { adminKey: string }) {
  const [items, setItems] = React.useState<ReviewItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filter, setFilter] = React.useState<"all" | "pending" | "approved">(
    "pending"
  );
  const { toast } = useToast();

  const load = React.useCallback(() => {
    setLoading(true);
    fetch("/api/admin/reviews", {
      headers: { authorization: `Bearer ${adminKey}` },
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setItems(d.items);
      })
      .finally(() => setLoading(false));
  }, [adminKey]);

  React.useEffect(() => {
    load();
  }, [load]);

  const approve = async (id: string, approved: boolean) => {
    try {
      const res = await fetch("/api/admin/reviews", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          authorization: `Bearer ${adminKey}`,
        },
        body: JSON.stringify({ id, approved }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error);
      toast({ title: approved ? "Ulasan disetujui" : "Ulasan ditolak" });
      load();
    } catch (e) {
      toast({
        title: "Gagal",
        description: e instanceof Error ? e.message : "",
        variant: "destructive",
      });
    }
  };

  const del = async (id: string) => {
    if (!confirm("Hapus ulasan ini permanen?")) return;
    try {
      const res = await fetch(`/api/admin/reviews?id=${id}`, {
        method: "DELETE",
        headers: { authorization: `Bearer ${adminKey}` },
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error);
      toast({ title: "Ulasan dihapus" });
      load();
    } catch (e) {
      toast({
        title: "Gagal hapus",
        description: e instanceof Error ? e.message : "",
        variant: "destructive",
      });
    }
  };

  const filtered =
    filter === "all"
      ? items
      : filter === "pending"
      ? items.filter((i) => !i.approved)
      : items.filter((i) => i.approved);

  const pendingCount = items.filter((i) => !i.approved).length;

  return (
    <div className="space-y-4">
      {/* Filter tabs */}
      <div className="flex flex-wrap gap-2">
        {(
          [
            ["pending", `Menunggu (${pendingCount})`],
            ["approved", "Disetujui"],
            ["all", "Semua"],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            type="button"
            onClick={() => setFilter(k)}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-sm font-medium transition",
              filter === k
                ? "bg-brand text-brand-foreground"
                : "bg-card border border-border hover:bg-muted"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-8 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
          Memuat...
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground bg-muted/40 rounded-2xl border border-border">
          <Star className="h-8 w-8 mx-auto mb-2 opacity-50" />
          Tidak ada ulasan {filter}.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((r) => (
            <div
              key={r.id}
              className={cn(
                "bg-card rounded-2xl border p-4",
                r.approved
                  ? "border-emerald-200 dark:border-emerald-500/30"
                  : "border-amber-200 dark:border-amber-500/30 bg-amber-50/40 dark:bg-amber-500/5"
              )}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-semibold text-foreground">{r.name}</p>
                    <span
                      className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase",
                        r.approved
                          ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400"
                          : "bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-400"
                      )}
                    >
                      {r.approved ? "Disetujui" : "Menunggu"}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className="flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, s) => (
                        <Star
                          key={s}
                          className={cn(
                            "h-3 w-3",
                            s < r.rating
                              ? "fill-gold text-gold"
                              : "fill-muted text-muted-foreground/40"
                          )}
                        />
                      ))}
                    </div>
                    {r.service && <span>• {r.service}</span>}
                    <span>• {r.role}</span>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(r.createdAt).toLocaleDateString("id-ID", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                  })}
                </span>
              </div>
              <p className="text-sm text-foreground/85 mb-3 italic">
                &ldquo;{r.comment}&rdquo;
              </p>
              <div className="flex gap-2">
                {!r.approved && (
                  <button
                    type="button"
                    onClick={() => approve(r.id, true)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition"
                  >
                    <Check className="h-3.5 w-3.5" /> Setujui
                  </button>
                )}
                {r.approved && (
                  <button
                    type="button"
                    onClick={() => approve(r.id, false)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-amber-100 text-amber-700 hover:bg-amber-200 dark:bg-amber-500/20 dark:text-amber-400 transition"
                  >
                    <X className="h-3.5 w-3.5" /> Batal Setuju
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => del(r.id)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Hapus
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
