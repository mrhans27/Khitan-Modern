"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { create } from "zustand";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Droplet,
  Loader2,
  CheckCircle2,
  MessageCircle,
  Calendar,
  User,
  Phone,
  MapPin,
  StickyNote,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { infusPackages, siteConfig } from "@/lib/site";

type InfusState = {
  open: boolean;
  preselectPackage: string | null;
  setOpen: (open: boolean) => void;
  openWithPackage: (pkg: string | null) => void;
};

export const useInfusStore = create<InfusState>((set) => ({
  open: false,
  preselectPackage: null,
  setOpen: (open) => set({ open }),
  openWithPackage: (pkg) => set({ open: true, preselectPackage: pkg }),
}));

export function InfusModal() {
  const { open, preselectPackage, setOpen } = useInfusStore();
  const { toast } = useToast();
  const [submitting, setSubmitting] = React.useState(false);
  const [success, setSuccess] = React.useState<{
    id: string;
    waUrl: string;
  } | null>(null);

  const [form, setForm] = React.useState({
    patientName: "",
    patientPhone: "",
    package: "vitamin-c-high",
    address: "",
    preferredDate: "",
    notes: "",
  });

  React.useEffect(() => {
    if (open && preselectPackage) {
      setForm((f) => ({ ...f, package: preselectPackage }));
    }
  }, [open, preselectPackage]);

  React.useEffect(() => {
    if (!open) {
      setSuccess(null);
      setSubmitting(false);
      setForm({
        patientName: "",
        patientPhone: "",
        package: "vitamin-c-high",
        address: "",
        preferredDate: "",
        notes: "",
      });
    }
  }, [open]);

  const update = (k: keyof typeof form, v: string) =>
    setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    if (!form.patientName.trim() || form.patientName.trim().length < 2) {
      toast({
        title: "Data belum lengkap",
        description: "Mohon isi nama pasien.",
        variant: "destructive",
      });
      return;
    }
    if (form.patientPhone.replace(/[^\d]/g, "").length < 9) {
      toast({
        title: "Nomor WhatsApp tidak valid",
        description: "Pastikan nomor WhatsApp aktif & benar.",
        variant: "destructive",
      });
      return;
    }
    if (!form.address.trim() || form.address.trim().length < 5) {
      toast({
        title: "Alamat wajib diisi",
        description: "Home service infus memerlukan alamat lengkap.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/infus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patientName: form.patientName,
          patientPhone: form.patientPhone,
          package: form.package,
          address: form.address,
          preferredDate: form.preferredDate || undefined,
          notes: form.notes,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || "Gagal memesan infus");
      }

      const pkg = infusPackages.find((p) => p.id === form.package);
      const pkgName = pkg?.name ?? form.package;
      const pkgPrice = pkg?.priceLabel ?? "";
      const waText = `Assalamualaikum, saya baru saja memesan layanan Infus Vitamin Homecare di Al-Asyraf.%0A%0ANama Pasien: ${form.patientName}%0APaket: ${pkgName} (${pkgPrice})%0AAlamat: ${form.address}%0A${form.preferredDate ? "Tanggal Preferensi: " + form.preferredDate : ""}%0A%0ANomor pesanan: ${data.id}%0A%0AMohon konfirmasi jadwalnya, terima kasih.`;
      const waUrl = `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(waText)}`;

      setSuccess({ id: data.id, waUrl });
      toast({
        title: "Pesanan berhasil dikirim!",
        description: "Tim kami akan menghubungi Anda via WhatsApp.",
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Terjadi kesalahan";
      toast({
        title: "Pemesanan gagal",
        description: message,
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const today = new Date().toISOString().split("T")[0];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[520px] max-h-[92vh] overflow-y-auto p-0 gap-0">
        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white p-6 rounded-t-xl">
          <DialogHeader className="p-0 space-y-1 text-left">
            <DialogTitle className="flex items-center gap-2 text-xl text-white">
              <Droplet className="h-5 w-5" />
              Pesan Infus Vitamin Homecare
            </DialogTitle>
            <DialogDescription className="text-white/80 text-sm">
              Isi data di bawah ini. Tenaga medis Al-Asyraf akan menghubungi
              Anda via WhatsApp untuk konfirmasi jadwal pemasangan.
            </DialogDescription>
          </DialogHeader>
        </div>

        {success ? (
          <SuccessView
            id={success.id}
            waUrl={success.waUrl}
            onClose={() => setOpen(false)}
          />
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <Field label="Nama Pasien" icon={User} required>
              <Input
                value={form.patientName}
                onChange={(e) => update("patientName", e.target.value)}
                placeholder="Nama lengkap pasien"
                disabled={submitting}
              />
            </Field>

            <Field label="Nomor WhatsApp Aktif" icon={Phone} required>
              <Input
                value={form.patientPhone}
                onChange={(e) => update("patientPhone", e.target.value)}
                placeholder="08xx-xxxx-xxxx"
                inputMode="tel"
                disabled={submitting}
              />
            </Field>

            <Field label="Paket Infus Vitamin" required>
              <Select
                value={form.package}
                onValueChange={(v) => update("package", v)}
                disabled={submitting}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {infusPackages.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} — {p.priceLabel}
                      {p.popular ? " (Terpopuler)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label="Alamat Pemasangan (Home Service)" icon={MapPin} required>
              <Textarea
                value={form.address}
                onChange={(e) => update("address", e.target.value)}
                placeholder="Alamat lengkap tempat pemasangan infus"
                rows={2}
                disabled={submitting}
                className="resize-none"
              />
            </Field>

            <Field label="Tanggal Preferensi (opsional)" icon={Calendar}>
              <Input
                type="date"
                value={form.preferredDate}
                min={today}
                onChange={(e) => update("preferredDate", e.target.value)}
                disabled={submitting}
              />
            </Field>

            <Field label="Catatan / Kondisi Pasien (opsional)" icon={StickyNote}>
              <Textarea
                value={form.notes}
                onChange={(e) => update("notes", e.target.value)}
                placeholder="Contoh: sedang demam, punya riwayat alergi, kondisi khusus..."
                rows={3}
                disabled={submitting}
                className="resize-none"
              />
            </Field>

            <Button
              type="submit"
              disabled={submitting}
              className="w-full h-12 bg-emerald-600 hover:bg-emerald-500 text-base font-semibold shadow-md"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Mengirim...
                </>
              ) : (
                <>
                  <Droplet className="h-4 w-4" /> Pesan Infus Sekarang
                </>
              )}
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              Dengan memesan, Anda menyetujui untuk dihubungi via WhatsApp oleh
              tim Al-Asyraf untuk konfirmasi jadwal pemasangan.
            </p>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  icon: Icon,
  required,
  children,
}: {
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium flex items-center gap-1.5">
        {Icon && <Icon className="h-4 w-4 text-emerald-600" />}
        {label}
        {required && <span className="text-destructive">*</span>}
      </Label>
      {children}
    </div>
  );
}

function SuccessView({
  id,
  waUrl,
  onClose,
}: {
  id: string;
  waUrl: string;
  onClose: () => void;
}) {
  return (
    <div className="p-8 text-center space-y-5">
      <motion.div
        initial={{ scale: 0, rotate: -20 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: "spring", stiffness: 200, damping: 15 }}
        className="mx-auto w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-500/20 flex items-center justify-center"
      >
        <CheckCircle2 className="h-12 w-12 text-emerald-600 dark:text-emerald-400" />
      </motion.div>
      <div>
        <h3 className="text-xl font-bold text-foreground mb-1">
          Pesanan Infus Berhasil!
        </h3>
        <p className="text-muted-foreground text-sm max-w-sm mx-auto">
          Terima kasih telah memesan layanan Infus Vitamin Homecare di Rumah
          Khitan Al-Asyraf. Nomor pesanan Anda:
        </p>
        <p className="mt-3 inline-block font-mono text-sm bg-muted px-4 py-2 rounded-lg border border-border tracking-wider">
          #{id.slice(-8).toUpperCase()}
        </p>
      </div>
      <div className="flex flex-col gap-2 pt-2">
        <a
          href={waUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-6 rounded-xl shadow-md transition"
        >
          <MessageCircle className="h-5 w-5" />
          Konfirmasi via WhatsApp
        </a>
        <Button type="button" variant="outline" onClick={onClose} className="w-full">
          Tutup
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        Tim medis kami akan menghubungi Anda secepatnya untuk konfirmasi
        jadwal pemasangan.
      </p>
    </div>
  );
}
