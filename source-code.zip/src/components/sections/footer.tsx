"use client";

import Image from "next/image";
import Link from "next/link";
import {
  MapPin,
  Phone,
  Clock,
  MessageCircle,
  CalendarPlus,
  Facebook,
  Instagram,
  Youtube,
} from "lucide-react";
import { siteConfig, navLinks, buildWhatsAppUrl } from "@/lib/site";
import { useDaftarStore, useAdminStore } from "@/store/ui";

export function Footer() {
  const openDaftar = useDaftarStore((s) => s.openWithMethod);

  const handleNav = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-foreground text-background/80 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative h-14 w-14 rounded-2xl overflow-hidden ring-2 ring-gold/60 bg-white p-0.5">
                <Image
                  src="/images/logo.png"
                  alt="Logo Al-Asyraf"
                  fill
                  sizes="56px"
                  className="object-cover rounded-xl"
                />
              </div>
              <div>
                <p className="text-lg font-bold text-gold tracking-wider">
                  AL-ASYRAF
                </p>
                <p className="text-xs text-background/60">
                  Rumah Khitan Modern
                </p>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-background/70 mb-4">
              Pusat khitan modern terpercaya di Situbondo. Memberikan
              kenyamanan & pengalaman khitan tanpa trauma untuk jagoan Anda.
            </p>
            <div className="flex gap-2">
              <SocialIcon icon={Facebook} label="Facebook" />
              <SocialIcon icon={Instagram} label="Instagram" />
              <SocialIcon icon={Youtube} label="YouTube" />
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wide">
              Navigasi
            </h4>
            <ul className="space-y-2.5 text-sm">
              {navLinks.slice(0, 6).map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNav(link.href);
                    }}
                    className="text-background/70 hover:text-gold transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Layanan */}
          <div>
            <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wide">
              Layanan
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  type="button"
                  onClick={() => openDaftar("cincin")}
                  className="text-background/70 hover:text-gold transition-colors text-left"
                >
                  Metode Cincin / Ring
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => openDaftar("lem")}
                  className="text-background/70 hover:text-gold transition-colors text-left"
                >
                  Metode Lem (Premium)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => openDaftar("jahit")}
                  className="text-background/70 hover:text-gold transition-colors text-left"
                >
                  Metode Jahit
                </button>
              </li>
              <li>
                <a
                  href="#infus"
                  onClick={(e) => {
                    e.preventDefault();
                    document
                      .querySelector("#infus")
                      ?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-background/70 hover:text-gold transition-colors flex items-center gap-1"
                >
                  Infus Vitamin Homecare
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-gold/30 text-gold uppercase">
                    Baru
                  </span>
                </a>
              </li>
              <li>
                <span className="text-background/70">Home Service</span>
              </li>
              <li>
                <span className="text-background/70">Kontrol Gratis</span>
              </li>
            </ul>
          </div>

          {/* Kontak */}
          <div>
            <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wide">
              Kontak
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="h-4 w-4 text-gold mt-0.5 flex-shrink-0" />
                <span className="text-background/70 leading-relaxed">
                  {siteConfig.address}
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 text-gold flex-shrink-0" />
                <a
                  href={`tel:+${siteConfig.whatsapp}`}
                  className="text-background/70 hover:text-gold transition-colors"
                >
                  {siteConfig.whatsappDisplay}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock className="h-4 w-4 text-gold flex-shrink-0" />
                <span className="text-background/70">{siteConfig.hours}</span>
              </li>
            </ul>
            <div className="mt-5 flex flex-col gap-2">
              <a
                href={buildWhatsAppUrl(
                  "Halo, saya ingin berkonsultasi tentang layanan khitan Al-Asyraf."
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 px-4 rounded-lg text-sm transition-colors"
              >
                <MessageCircle className="h-4 w-4" /> WhatsApp
              </a>
              <button
                type="button"
                onClick={() => openDaftar(null)}
                className="inline-flex items-center justify-center gap-2 bg-gold hover:bg-gold/90 text-gold-foreground font-semibold py-2.5 px-4 rounded-lg text-sm transition-colors"
              >
                <CalendarPlus className="h-4 w-4" /> Daftar Online
              </button>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-background/15 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-background/50">
          <p>&copy; {new Date().getFullYear()} Rumah Khitan Al-Asyraf. Semua Hak Dilindungi.</p>
          <div className="flex items-center gap-3">
            <p>Khitan Modern Situbondo &middot; Dibuat dengan dedikasi untuk jagoan Indonesia</p>
            <span className="h-1 w-1 rounded-full bg-gold/40" />
            <button
              type="button"
              onClick={() => useAdminStore.getState().setOpen(true)}
              className="text-background/40 hover:text-gold transition-colors"
              title="Panel Admin (Ctrl+Shift+A)"
              aria-label="Buka Panel Admin"
            >
              Admin
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialIcon({
  icon: Icon,
  label,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}) {
  return (
    <a
      href="#"
      aria-label={label}
      onClick={(e) => e.preventDefault()}
      className="h-9 w-9 rounded-lg bg-background/10 hover:bg-gold hover:text-gold-foreground flex items-center justify-center transition-colors text-background/80"
    >
      <Icon className="h-4 w-4" />
    </a>
  );
}
