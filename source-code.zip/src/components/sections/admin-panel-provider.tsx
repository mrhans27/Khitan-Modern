"use client";

import * as React from "react";
import { AdminPanel } from "./admin-panel";
import { useAdminStore } from "@/store/ui";

export function AdminPanelProvider() {
  const { open, setOpen } = useAdminStore();

  // Keyboard shortcut: Ctrl/Cmd + Shift + A opens admin panel
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "a") {
        e.preventDefault();
        setOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setOpen]);

  return <AdminPanel open={open} onOpenChange={setOpen} />;
}
