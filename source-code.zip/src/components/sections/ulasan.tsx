"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Star,
  MessageSquare,
  Send,
  Loader2,
  CheckCircle2,
  Quote,
  PenLine,
} from "lucide-react";
import { SectionHeading } from "./keunggulan";
import { cn } from "@/lib/utils";

type Review = {
  id: string;
  name: string;
  role: string;
  rating: number;
  comment: string;
  service: string | null;
  createdAt: string;
};

export function Ulasan() {
  const [reviews, setReviews] = React.useState<Review[]>([]);
  const [average, setAverage] = React.useState(0);
  const [total, setTotal] = React.useState(0);
  const [loading, setLoading] = React.useState(true);
  const [showForm, setShowForm] = React.useState(false);

  const loadReviews = React.useCallback(async () => {
    try {
      const res = await fetch("/api/reviews?limit=50", { cache: "no-store" });
      const data = await res.json();
      if (data.ok) {
        setReviews(data.reviews);
        setAverage(data.average);
        setTotal(data.total);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadReviews();
  }, [loadReviews]);

  return (
    <section
      id="ulasan"
      className="py-20 md:py-28 bg-background px-4 scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 gradient-mesh opacity-40 pointer-events-none" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeading
          eyebrow="Komentar & Ulasan"
          title="Ulasan Pasien & Pelanggan"
          subtitle="Bagikan pengalaman Anda dan baca ulasan dari pasien/pelanggan lain yang telah mempercayakan layanan Al-Asyraf."
        />

        {/* Summary + CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="bg-card rounded-3xl border border-border card-modern p-6 md:p-7 mb-8 flex flex-col sm:flex-row items-center justify-between gap-5"
        >
          <div className="flex items-center gap-4">
            <div className="text-center">
              <div className="text-4xl font-extrabold text-foreground leading-none">
                {average > 0 ? average.toFixed(1) : "—"}
              </div>
              <div className="flex gap-0.5 justify-center mt-1.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={cn(
                      "h-4 w-4",
                      i < Math.round(average)
                        ? "fill-gold text-gold"
                        : "fill-muted text-muted-foreground/40"
                    )}
                  />
                ))}
              </div>
            </div>
            <div className="h-12 w-px bg-border hidden sm:block" />
            <div>
              <p className="font-semibold text-foreground">
                {total} Ulasan Terverifikasi
              </p>
              <p className="text-sm text-muted-foreground">
                {total > 0
                  ? "Berdasarkan pengalaman pasien & pelanggan nyata"
                  : "Jadilah yang pertama memberi ulasan!"}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowForm((v) => !v)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand hover:bg-brand/90 text-brand-foreground font-semibold px-6 py-3 rounded-2xl shadow-md transition hover:-translate-y-0.5"
          >
            <PenLine className="h-4 w-4" />
            {showForm ? "Tutup Form" : "Tulis Ulasan"}
          </button>
        </motion.div>

        {/* Review form */}
        {showForm && (
          <ReviewForm
            onClose={() => setShowForm(false)}
            onSubmitted={() => {
              setShowForm(false);
              loadReviews();
            }}
          />
        )}

        {/* Reviews list */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className="bg-card rounded-3xl border border-border p-6 h-44 animate-pulse"
              />
            ))}
          </div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-12 bg-muted/40 rounded-3xl border border-border">
            <MessageSquare className="h-10 w-10 text-muted-foreground/50 mx-auto mb-3" />
            <p className="font-semibold text-foreground mb-1">
              Belum ada ulasan
            </p>
            <p className="text-sm text-muted-foreground">
              Jadilah yang pertama berbagi pengalaman Anda!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {reviews.map((r, i) => (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, delay: i * 0.04 }}
                className="bg-card rounded-3xl border border-border card-modern card-modern-hover p-6 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-full -mr-8 -mt-8" />
                <div className="flex items-center justify-between mb-3 relative">
                  <div className="flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, s) => (
                      <Star
                        key={s}
                        className={cn(
                          "h-4 w-4",
                          s < r.rating
                            ? "fill-gold text-gold"
                            : "fill-muted text-muted-foreground/40"
                        )}
                      />
                    ))}
                  </div>
                  <Quote className="h-8 w-8 text-brand/12" />
                </div>
                <p className="text-foreground/85 text-sm leading-relaxed mb-4 italic text-pretty">
                  &ldquo;{r.comment}&rdquo;
                </p>
                <div className="flex items-center gap-3 pt-4 border-t border-border">
                  <div className="w-10 h-10 rounded-2xl gradient-brand text-white flex items-center justify-center font-bold text-sm shadow-md">
                    {r.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm truncate">
                      {r.name}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {r.service ? `${r.service} • ` : ""}
                      {r.role}
                    </p>
                  </div>
                  <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                    {new Date(r.createdAt).toLocaleDateString("id-ID", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                    })}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function ReviewForm({
  onClose,
  onSubmitted,
}: {
  onClose: () => void;
  onSubmitted: () => void;
}) {
  const [name, setName] = React.useState("");
  const [role, setRole] = React.useState("");
  const [service, setService] = React.useState("");
  const [rating, setRating] = React.useState(5);
  const [hover, setHover] = React.useState(0);
  const [comment, setComment] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setErr(null);
    if (name.trim().length < 2) {
      setErr("Nama minimal 2 karakter");
      return;
    }
    if (comment.trim().length < 5) {
      setErr("Ulasan minimal 5 karakter");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          role: role || undefined,
          service: service || undefined,
          rating,
          comment,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Gagal");
      setDone(true);
      setTimeout(() => {
        onSubmitted();
      }, 1800);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Terjadi kesalahan");
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20, height: 0 }}
        animate={{ opacity: 1, y: 0, height: "auto" }}
        exit={{ opacity: 0, height: 0 }}
        className="bg-card rounded-3xl border border-emerald-200 dark:border-emerald-500/30 p-8 text-center mb-8"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="mx-auto w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-500/20 flex items-center justify-center mb-4"
        >
          <CheckCircle2 className="h-9 w-9 text-emerald-600 dark:text-emerald-400" />
        </motion.div>
        <h3 className="font-bold text-lg text-foreground mb-1">
          Terima Kasih atas Ulasan Anda!
        </h3>
        <p className="text-sm text-muted-foreground max-w-md mx-auto">
          Ulasan Anda berhasil dikirim. Setelah disetujui oleh admin, ulasan
          akan tampil di halaman ini.
        </p>
      </motion.div>
    );
  }

  return (
    <motion.form
      onSubmit={submit}
      initial={{ opacity: 0, y: 20, height: 0 }}
      animate={{ opacity: 1, y: 0, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      className="bg-card rounded-3xl border border-border card-modern p-6 md:p-7 mb-8 space-y-4"
    >
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-lg text-foreground flex items-center gap-2">
          <PenLine className="h-5 w-5 text-brand" />
          Bagikan Pengalaman Anda
        </h3>
        <button
          type="button"
          onClick={onClose}
          className="text-sm text-muted-foreground hover:text-foreground transition"
        >
          Tutup
        </button>
      </div>

      {/* Star rating */}
      <div>
        <label className="text-sm font-medium text-foreground mb-2 block">
          Rating Anda <span className="text-destructive">*</span>
        </label>
        <div className="flex gap-1.5">
          {Array.from({ length: 5 }).map((_, i) => {
            const v = i + 1;
            return (
              <button
                key={v}
                type="button"
                aria-label={`${v} bintang`}
                onClick={() => setRating(v)}
                onMouseEnter={() => setHover(v)}
                onMouseLeave={() => setHover(0)}
                className="p-1 transition-transform hover:scale-110"
              >
                <Star
                  className={cn(
                    "h-8 w-8 transition-colors",
                    v <= (hover || rating)
                      ? "fill-gold text-gold"
                      : "fill-muted text-muted-foreground/40"
                  )}
                />
              </button>
            );
          })}
          <span className="ml-2 self-center text-sm text-muted-foreground">
            {rating} / 5
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">
            Nama <span className="text-destructive">*</span>
          </label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nama Anda"
            maxLength={80}
            className="w-full h-10 px-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand/40 transition"
          />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">
            Peran (opsional)
          </label>
          <input
            value={role}
            onChange={(e) => setRole(e.target.value)}
            placeholder="Cth: Orang tua jagoan"
            maxLength={80}
            className="w-full h-10 px-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand/40 transition"
          />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">
            Layanan (opsional)
          </label>
          <select
            value={service}
            onChange={(e) => setService(e.target.value)}
            className="w-full h-10 px-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand/40 transition"
          >
            <option value="">— Pilih —</option>
            <option value="Khitan Metode Cincin">Khitan Cincin</option>
            <option value="Khitan Metode Lem">Khitan Lem</option>
            <option value="Khitan Metode Jahit">Khitan Jahit</option>
            <option value="Infus Vitamin Homecare">Infus Vitamin</option>
            <option value="Home Service">Home Service</option>
          </select>
        </div>
      </div>

      <div>
        <label className="text-sm font-medium text-foreground mb-1.5 block">
          Ulasan / Komentar <span className="text-destructive">*</span>
        </label>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Bagikan pengalaman Anda selama menggunakan layanan Al-Asyraf..."
          rows={4}
          maxLength={800}
          className="w-full px-3 py-2.5 rounded-xl border border-border bg-background text-sm resize-none focus:outline-none focus:ring-2 focus:ring-brand/40 focus:border-brand/40 transition"
        />
        <p className="text-xs text-muted-foreground mt-1">
          {comment.length}/800 karakter
        </p>
      </div>

      {err && (
        <p className="text-sm text-destructive bg-destructive/10 px-3 py-2 rounded-lg">
          {err}
        </p>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand hover:bg-brand/90 text-brand-foreground font-semibold px-6 py-3 rounded-2xl shadow-md transition disabled:opacity-60"
      >
        {submitting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" /> Mengirim...
          </>
        ) : (
          <>
            <Send className="h-4 w-4" /> Kirim Ulasan
          </>
        )}
      </button>
      <p className="text-xs text-muted-foreground">
        Ulasan akan tampil setelah disetujui admin untuk menjaga kualitas.
      </p>
    </motion.form>
  );
}
