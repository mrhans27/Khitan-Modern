"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CalendarPlus,
  Loader2,
  CheckCircle2,
  MessageCircle,
  Calendar,
  User,
  Phone,
  Home,
  StickyNote,
} from "lucide-react";
import { useDaftarStore } from "@/store/ui";
import { useToast } from "@/hooks/use-toast";
import { methods, siteConfig, buildWhatsAppUrl } from "@/lib/site";
import { cn } from "@/lib/utils";

export function DaftarModal() {
  const { open, preselectMethod, setOpen } = useDaftarStore();
  const { toast } = useToast();
  const [submitting, setSubmitting] = React.useState(false);
  const [success, setSuccess] = React.useState<{ id: string; waUrl: string } | null>(null);

  const [form, setForm] = React.useState({
    parentName: "",
    parentPhone: "",
    childName: "",
    childAge: "",
    method: "cincin",
    homeService: false,
    address: "",
    preferredDate: "",
    notes: "",
  });

  // Sync preselect method
  React.useEffect(() => {
    if (open && preselectMethod) {
      setForm((f) => ({ ...f, method: preselectMethod }));
    }
  }, [open, preselectMethod]);

  // Reset on close
  React.useEffect(() => {
    if (!open) {
      setSuccess(null);
      setSubmitting(false);
      setForm({
        parentName: "",
        parentPhone: "",
        childName: "",
        childAge: "",
        method: "cincin",
        homeService: false,
        address: "",
        preferredDate: "",
        notes: "",
      });
    }
  }, [open]);

  const update = (k: keyof typeof form, v: string | boolean) =>
    setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    // Basic validation
    if (!form.parentName.trim() || form.parentName.trim().length < 2) {
      toast({
        title: "Data belum lengkap",
        description: "Mohon isi nama orang tua/wali.",
        variant: "destructive",
      });
      return;
    }
    if (form.parentPhone.replace(/[^\d]/g, "").length < 9) {
      toast({
        title: "Nomor WhatsApp tidak valid",
        description: "Pastikan nomor WhatsApp aktif & benar.",
        variant: "destructive",
      });
      return;
    }
    if (!form.childName.trim() || form.childName.trim().length < 2) {
      toast({
        title: "Data belum lengkap",
        description: "Mohon isi nama jagoan.",
        variant: "destructive",
      });
      return;
    }
    const ageNum = Number(form.childAge);
    if (!Number.isFinite(ageNum) || ageNum < 1 || ageNum > 100) {
      toast({
        title: "Usia tidak valid",
        description: "Isi usia jagoan (1-100 tahun).",
        variant: "destructive",
      });
      return;
    }
    if (form.homeService && !form.address.trim()) {
      toast({
        title: "Alamat wajib diisi",
        description: "Home service memerlukan alamat lokasi.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/daftar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          parentName: form.parentName,
          parentPhone: form.parentPhone,
          childName: form.childName,
          childAge: ageNum,
          method: form.method,
          homeService: form.homeService,
          address: form.address,
          preferredDate: form.preferredDate || undefined,
          notes: form.notes,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || "Gagal mendaftar");
      }

      const methodName = methods.find((m) => m.id === form.method)?.name ?? form.method;
      const waText = `Assalamualaikum, saya baru saja mendaftar online khitan di Al-Asyraf.%0A%0ANama Wali: ${form.parentName}%0ANama Jagoan: ${form.childName}%0AUsia: ${ageNum} tahun%0AMetode: ${methodName}$0A${form.homeService ? "Home Service: Ya" : "Home Service: Tidak"}%0A${form.preferredDate ? "Tanggal Preferensi: " + form.preferredDate : ""}%0A%0ANomor pendaftaran: ${data.id}%0A%0AMohon konfirmasi jadwalnya, terima kasih.`;
      const waUrl = `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(waText)}`;

      setSuccess({ id: data.id, waUrl });
      toast({
        title: "Pendaftaran berhasil!",
        description: "Tim kami akan menghubungi Anda via WhatsApp.",
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Terjadi kesalahan";
      toast({
        title: "Pendaftaran gagal",
        description: message,
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const today = new Date().toISOString().split("T")[0];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[520px] max-h-[92vh] overflow-y-auto p-0 gap-0">
        <div className="bg-gradient-to-br from-brand to-brand/85 text-white p-6 rounded-t-xl">
          <DialogHeader className="p-0 space-y-1 text-left">
            <DialogTitle className="flex items-center gap-2 text-xl text-white">
              <CalendarPlus className="h-5 w-5 text-gold" />
              Pendaftaran Online Khitan
            </DialogTitle>
            <DialogDescription className="text-white/80 text-sm">
              Isi data di bawah ini. Tim Al-Asyraf akan menghubungi Anda via
              WhatsApp untuk konfirmasi jadwal.
            </DialogDescription>
          </DialogHeader>
        </div>

        {success ? (
          <SuccessView
            id={success.id}
            waUrl={success.waUrl}
            onClose={() => setOpen(false)}
          />
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <Field label="Nama Orang Tua / Wali" icon={User} required>
              <Input
                value={form.parentName}
                onChange={(e) => update("parentName", e.target.value)}
                placeholder="Contoh: Bapak Ahmad"
                disabled={submitting}
              />
            </Field>

            <Field label="Nomor WhatsApp Aktif" icon={Phone} required>
              <Input
                value={form.parentPhone}
                onChange={(e) => update("parentPhone", e.target.value)}
                placeholder="08xx-xxxx-xxxx"
                inputMode="tel"
                disabled={submitting}
              />
            </Field>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Nama Jagoan" icon={User} required>
                <Input
                  value={form.childName}
                  onChange={(e) => update("childName", e.target.value)}
                  placeholder="Nama putra Anda"
                  disabled={submitting}
                />
              </Field>
              <Field label="Usia (tahun)" required>
                <Input
                  value={form.childAge}
                  onChange={(e) => update("childAge", e.target.value)}
                  placeholder="Contoh: 7"
                  inputMode="numeric"
                  disabled={submitting}
                />
              </Field>
            </div>

            <Field label="Metode Khitan" required>
              <Select
                value={form.method}
                onValueChange={(v) => update("method", v)}
                disabled={submitting}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {methods.map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.name} — {m.priceLabel}
                      {m.popular ? " (Terpopuler)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label="Tanggal Preferensi (opsional)" icon={Calendar}>
              <Input
                type="date"
                value={form.preferredDate}
                min={today}
                onChange={(e) => update("preferredDate", e.target.value)}
                disabled={submitting}
              />
            </Field>

            <div className="rounded-xl border border-border p-4 bg-muted/40 space-y-3">
              <div className="flex items-start gap-3">
                <Checkbox
                  id="home"
                  checked={form.homeService}
                  onCheckedChange={(v) => update("homeService", v === true)}
                  disabled={submitting}
                  className="mt-0.5 data-[state=checked]:bg-brand data-[state=checked]:border-brand"
                />
                <div className="flex-1">
                  <label
                    htmlFor="home"
                    className="text-sm font-medium flex items-center gap-1.5 cursor-pointer"
                  >
                    <Home className="h-4 w-4 text-brand" />
                    Layanan Panggilan (Home Service)
                  </label>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Tambahan Rp 50.000 menyesuaikan jarak tempuh.
                  </p>
                </div>
              </div>
              <AnimatePresence>
                {form.homeService && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <Input
                      value={form.address}
                      onChange={(e) => update("address", e.target.value)}
                      placeholder="Alamat lengkap untuk home service"
                      disabled={submitting}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Field label="Catatan (opsional)" icon={StickyNote}>
              <Textarea
                value={form.notes}
                onChange={(e) => update("notes", e.target.value)}
                placeholder="Kondisi khusus, pertanyaan, atau hal yang perlu diketahui tim kami..."
                rows={3}
                disabled={submitting}
                className="resize-none"
              />
            </Field>

            <Button
              type="submit"
              disabled={submitting}
              className="w-full h-12 bg-brand hover:bg-brand/90 text-base font-semibold shadow-md"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Mengirim...
                </>
              ) : (
                <>
                  <CalendarPlus className="h-4 w-4" /> Daftar Sekarang
                </>
              )}
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              Dengan mendaftar, Anda menyetujui untuk dihubungi via WhatsApp oleh
              tim Al-Asyraf.
            </p>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  icon: Icon,
  required,
  children,
}: {
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium flex items-center gap-1.5">
        {Icon && <Icon className="h-4 w-4 text-brand" />}
        {label}
        {required && <span className="text-destructive">*</span>}
      </Label>
      {children}
    </div>
  );
}

function SuccessView({
  id,
  waUrl,
  onClose,
}: {
  id: string;
  waUrl: string;
  onClose: () => void;
}) {
  return (
    <div className="p-8 text-center space-y-5">
      <motion.div
        initial={{ scale: 0, rotate: -20 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: "spring", stiffness: 200, damping: 15 }}
        className="mx-auto w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-500/20 flex items-center justify-center"
      >
        <CheckCircle2 className="h-12 w-12 text-emerald-600 dark:text-emerald-400" />
      </motion.div>
      <div>
        <h3 className="text-xl font-bold text-foreground mb-1">
          Pendaftaran Berhasil!
        </h3>
        <p className="text-muted-foreground text-sm max-w-sm mx-auto">
          Terima kasih telah mendaftar di Rumah Khitan Al-Asyraf. Nomor
          pendaftaran Anda:
        </p>
        <p className="mt-3 inline-block font-mono text-sm bg-muted px-4 py-2 rounded-lg border border-border tracking-wider">
          #{id.slice(-8).toUpperCase()}
        </p>
      </div>
      <div className="flex flex-col gap-2 pt-2">
        <a
          href={waUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-6 rounded-xl shadow-md transition"
        >
          <MessageCircle className="h-5 w-5" />
          Konfirmasi via WhatsApp
        </a>
        <Button
          type="button"
          variant="outline"
          onClick={onClose}
          className="w-full"
        >
          Tutup
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        Tim kami akan menghubungi Anda secepatnya untuk konfirmasi jadwal.
      </p>
    </div>
  );
}
