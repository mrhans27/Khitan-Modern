"use client";

import * as React from "react";
import { motion, useInView, animate } from "framer-motion";
import { stats } from "@/lib/site";

function Counter({
  value,
  suffix,
  duration = 2,
}: {
  value: number;
  suffix: string;
  duration?: number;
}) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const [display, setDisplay] = React.useState(0);

  React.useEffect(() => {
    if (!inView) return;
    const controls = animate(0, value, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => setDisplay(Math.floor(v)),
    });
    return () => controls.stop();
  }, [inView, value, duration]);

  return (
    <span ref={ref} className="tabular-nums">
      {display.toLocaleString("id-ID")}
      {suffix}
    </span>
  );
}

export function Stats() {
  return (
    <section className="relative py-16 md:py-20 overflow-hidden">
      {/* Brand gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand via-brand to-brand/85 -z-10" />
      <div className="absolute inset-0 bg-pattern opacity-15 -z-10" />
      <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-gold/20 blur-[120px] -z-10 animate-float" />
      <div
        className="absolute -bottom-24 -right-24 w-96 h-96 rounded-full bg-brand-light/40 blur-[120px] -z-10 animate-float"
        style={{ animationDelay: "-3s" }}
      />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5 text-center">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass-card rounded-3xl p-5 md:p-7 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-gold/0 to-gold/5 group-hover:to-gold/15 transition-colors duration-500" />
              <div className="relative">
                <div className="text-3xl md:text-5xl font-extrabold text-gold mb-2 leading-none">
                  <Counter value={s.value} suffix={s.suffix} />
                </div>
                <div className="text-white/75 text-xs md:text-sm font-medium uppercase tracking-wider">
                  {s.label}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
