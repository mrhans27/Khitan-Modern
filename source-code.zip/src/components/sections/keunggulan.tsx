"use client";

import { motion } from "framer-motion";
import {
  Syringe,
  Bandage,
  Activity,
  HeartHandshake,
  type LucideIcon,
} from "lucide-react";
import { advantages } from "@/lib/site";

const iconMap: Record<string, LucideIcon> = {
  Syringe,
  Bandage,
  Activity,
  HeartHandshake,
};

const colorMap: Record<string, string> = {
  emerald:
    "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400",
  amber:
    "bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400",
  yellow:
    "bg-yellow-100 text-yellow-600 dark:bg-yellow-500/15 dark:text-yellow-400",
  teal: "bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400",
};

export function Keunggulan() {
  return (
    <section
      id="keunggulan"
      className="py-20 md:py-28 bg-background px-4 scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 gradient-mesh opacity-60 pointer-events-none" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeading
          eyebrow="Kenapa Al-Asyraf"
          title="Mengapa Memilih Khitan Modern?"
          subtitle="Metode modern memberikan kenyamanan maksimal bagi jagoan Anda dengan proses yang cepat dan minim risiko."
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
          {advantages.map((adv, i) => {
            const Icon = iconMap[adv.icon] ?? Syringe;
            return (
              <motion.div
                key={adv.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="group card-hover bg-card p-6 md:p-7 rounded-3xl border border-border card-modern card-modern-hover text-center relative overflow-hidden"
              >
                {/* Gradient glow on hover */}
                <div
                  className={`absolute -top-10 left-1/2 -translate-x-1/2 w-32 h-32 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 ${
                    adv.color === "emerald"
                      ? "bg-emerald-400/20"
                      : adv.color === "amber"
                      ? "bg-amber-400/20"
                      : adv.color === "yellow"
                      ? "bg-yellow-400/20"
                      : "bg-teal-400/20"
                  }`}
                />
                <div
                  className={`relative w-14 h-14 md:w-16 md:h-16 rounded-2xl flex items-center justify-center mx-auto mb-5 transition-transform duration-500 group-hover:scale-110 ${
                    colorMap[adv.color] ?? colorMap.emerald
                  }`}
                >
                  <Icon className="h-7 w-7 md:h-8 md:w-8" />
                </div>
                <h3 className="font-bold text-lg md:text-xl mb-2 text-foreground">
                  {adv.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed text-pretty">
                  {adv.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function SectionHeading({
  title,
  subtitle,
  eyebrow,
  light = false,
  align = "center",
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  light?: boolean;
  align?: "center" | "left";
}) {
  return (
    <div
      className={
        align === "left"
          ? "mb-12 text-left"
          : "mb-12 text-center mx-auto max-w-2xl"
      }
    >
      {eyebrow && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4 }}
          className={`mb-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider ${
            light
              ? "bg-white/10 text-gold border border-gold/30"
              : "bg-brand/10 text-brand border border-brand/15"
          }`}
        >
          <span className="h-1.5 w-1.5 rounded-full bg-gold" />
          {eyebrow}
        </motion.div>
      )}
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className={`text-3xl md:text-4xl lg:text-[2.75rem] font-bold mb-4 leading-tight text-balance ${
          light ? "text-white" : "text-foreground"
        }`}
      >
        {title}
      </motion.h2>
      {align === "center" && (
        <div className="h-1 w-16 bg-gradient-gold rounded-full mb-4" />
      )}
      {subtitle && (
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className={`text-base md:text-lg ${
            light ? "text-white/80" : "text-muted-foreground"
          } text-pretty`}
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}
