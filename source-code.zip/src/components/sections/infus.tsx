"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  ShieldPlus,
  FlaskConical,
  HeartPulse,
  Home,
  BadgeCheck,
  ShieldCheck,
  Wallet,
  Droplet,
  Clock,
  Check,
  Star,
  MapPin,
  type LucideIcon,
} from "lucide-react";
import { infusPackages, infusBenefits, buildWhatsAppUrl } from "@/lib/site";
import { SectionHeading } from "./keunggulan";
import { InfusModal, useInfusStore } from "./infus-modal";
import { cn } from "@/lib/utils";

const iconMap: Record<string, LucideIcon> = {
  ShieldPlus,
  FlaskConical,
  HeartPulse,
};

const colorMap: Record<string, string> = {
  emerald:
    "from-emerald-500 to-emerald-700 text-white",
  amber: "from-amber-500 to-amber-600 text-white",
  teal: "from-teal-500 to-teal-700 text-white",
  rose: "from-rose-500 to-rose-700 text-white",
};

const benefitIconMap: Record<string, LucideIcon> = {
  Home,
  BadgeCheck,
  ShieldCheck,
  Wallet,
};

export function Infus() {
  const openInfus = useInfusStore((s) => s.openWithPackage);

  return (
    <section
      id="infus"
      className="py-16 md:py-24 bg-gradient-to-b from-emerald-50/60 to-background dark:from-emerald-500/5 px-4 scroll-mt-20"
    >
      <div className="max-w-6xl mx-auto">
        <SectionHeading
          title="Layanan Homecare Infus Vitamin"
          subtitle="Pemasangan infus vitamin langsung di rumah Anda, oleh tenaga medis bersertifikat. Tingkatkan imunitas & stamina tanpa antri."
        />

        {/* Intro banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto mb-10 bg-card border border-emerald-100 dark:border-emerald-500/20 rounded-2xl p-5 flex items-start gap-4 shadow-sm"
        >
          <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md">
            <Droplet className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-bold text-foreground mb-1 flex items-center gap-2 flex-wrap">
              Infus Vitamin Home Service
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 uppercase tracking-wide">
                <Star className="h-3 w-3 fill-emerald-600 text-emerald-600" />
                Layanan Baru
              </span>
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Tenaga medis kami datang ke rumah Anda untuk memasang infus
              vitamin. Nyaman, aman, dan jauh lebih hemat tenaga dibanding
              pergi ke klinik. Cocok untuk yang sedang kurang sehat, sibuk,
              atau butuh boost imunitas cepat.
            </p>
          </div>
        </motion.div>

        {/* Benefits grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {infusBenefits.map((b, i) => {
            const Icon = benefitIconMap[b.icon] ?? Home;
            return (
              <motion.div
                key={b.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="bg-card rounded-2xl p-4 sm:p-5 border border-border shadow-sm card-hover text-center"
              >
                <div className="h-12 w-12 mx-auto mb-3 rounded-xl bg-emerald-100 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Icon className="h-6 w-6" />
                </div>
                <h4 className="font-semibold text-foreground text-sm mb-1">
                  {b.title}
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {b.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Packages heading */}
        <div className="text-center mb-8">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            Pilih Paket Infus Vitamin
          </h3>
          <div className="h-1 w-20 bg-gold mx-auto rounded-full mb-3" />
          <p className="text-muted-foreground text-sm max-w-xl mx-auto">
            Semua paket sudah termasuk pemeriksaan awal, alat steril, & ongkos
            home service untuk area Asembagus & sekitarnya.
          </p>
        </div>

        {/* Package cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {infusPackages.map((p, i) => {
            const Icon = iconMap[p.icon] ?? ShieldPlus;
            const gradient = colorMap[p.color] ?? colorMap.emerald;
            return (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.45, delay: i * 0.08 }}
                className={cn(
                  "relative bg-card rounded-2xl overflow-hidden flex flex-col card-hover border",
                  p.popular
                    ? "border-2 border-emerald-500 shadow-lg"
                    : "border-border shadow-sm"
                )}
              >
                {p.badge && (
                  <div
                    className={cn(
                      "absolute top-0 right-0 text-white text-[10px] font-bold px-3 py-1 rounded-bl-lg uppercase tracking-wider flex items-center gap-1",
                      p.popular ? "bg-emerald-500" : "bg-amber-500"
                    )}
                  >
                    {p.popular && <Star className="h-2.5 w-2.5 fill-white" />}
                    {p.badge}
                  </div>
                )}

                {/* Icon header */}
                <div
                  className={cn(
                    "h-24 flex items-center justify-center bg-gradient-to-br",
                    gradient
                  )}
                >
                  <Icon className="h-12 w-12" />
                </div>

                <div className="p-5 flex-grow flex flex-col">
                  <h4 className="font-bold text-foreground text-lg mb-1">
                    {p.name}
                  </h4>
                  <p className="text-muted-foreground text-xs mb-4 leading-relaxed min-h-[2.5rem]">
                    {p.tagline}
                  </p>

                  <div className="mb-3">
                    <div className="text-2xl font-bold text-foreground">
                      {p.priceLabel.split(".")[0]}
                      <span className="text-sm text-muted-foreground font-normal">
                        .{p.priceLabel.split(".").slice(1).join(".")}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                      <Clock className="h-3 w-3" />
                      {p.duration}
                    </div>
                  </div>

                  <ul className="space-y-1.5 mb-5 flex-grow">
                    {p.features.map((f) => (
                      <li
                        key={f}
                        className="flex items-start gap-1.5 text-xs text-muted-foreground"
                      >
                        <span className="mt-0.5 flex-shrink-0 w-4 h-4 rounded-full bg-emerald-100 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                          <Check className="h-2.5 w-2.5" strokeWidth={3} />
                        </span>
                        {f}
                      </li>
                    ))}
                  </ul>

                  <button
                    type="button"
                    onClick={() => openInfus(p.id)}
                    className={cn(
                      "block w-full text-center font-semibold py-2.5 rounded-xl transition-all text-sm",
                      p.popular
                        ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-md hover:-translate-y-0.5"
                        : "bg-card text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/40 hover:bg-emerald-50 dark:hover:bg-emerald-500/10"
                    )}
                  >
                    Pesan Sekarang
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Info note */}
        <div className="max-w-3xl mx-auto mt-8 bg-emerald-50 dark:bg-emerald-500/10 p-4 rounded-xl border border-emerald-100 dark:border-emerald-500/20 flex items-start gap-3">
          <MapPin className="h-5 w-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-emerald-800 dark:text-emerald-300">
            <span className="font-semibold">Area layanan home service:</span>{" "}
            Asembagus, Banyuputih, Kapongan & sekitarnya. Untuk lokasi lebih jauh
            silakan konsultasi via WhatsApp untuk penyesuaian biaya transport.
          </p>
        </div>

        <div className="text-center mt-6">
          <a
            href={buildWhatsAppUrl(
              "Halo, saya ingin konsultasi tentang layanan infus vitamin homecare di Al-Asyraf."
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-emerald-700 dark:text-emerald-400 hover:text-emerald-600 dark:hover:text-emerald-300 font-semibold text-sm transition-colors"
          >
            <Droplet className="h-4 w-4" />
            Konsultasi paket infus via WhatsApp →
          </a>
        </div>
      </div>

      {/* Modal */}
      <InfusModal />
    </section>
  );
}
