"use client";

import * as React from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Gift, Search, X } from "lucide-react";
import { facilities } from "@/lib/site";

export function Fasilitas() {
  const [active, setActive] = React.useState<number | null>(null);

  return (
    <section
      id="fasilitas"
      className="py-16 md:py-24 px-4 relative overflow-hidden scroll-mt-20"
    >
      {/* Brand background panel */}
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="bg-gradient-to-br from-brand to-brand/90 rounded-3xl p-8 md:p-12 text-white shadow-2xl overflow-hidden relative">
          <div className="absolute inset-0 bg-pattern opacity-20" />
          <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-gold/20 blur-3xl" />

          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 relative z-10">
            <div className="md:w-1/2 text-center md:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold/20 text-gold text-xs font-semibold mb-4">
                <Gift className="h-3.5 w-3.5" /> BONUS SPESIAL
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gold">
                Setiap Khitan Mendapatkan Fasilitas GRATIS!
              </h2>
              <p className="text-white/85 mb-2 text-lg">
                Kami memanjakan jagoan Anda dengan hadiah spesial untuk
                pengalaman khitan yang tak terlupakan.
              </p>
              <p className="text-white/70 text-sm flex items-center gap-2 md:justify-start justify-center">
                <Search className="h-4 w-4 text-gold" />
                Klik item di bawah untuk melihat gambarnya!
              </p>
            </div>

            <div className="md:w-1/2 w-full grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
              {facilities.map((f, i) => (
                <motion.button
                  key={f.name}
                  type="button"
                  onClick={() => setActive(i)}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  className="glass-card rounded-xl p-3 text-center hover:bg-white/20 transition cursor-pointer group"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 mx-auto mb-2 rounded-xl overflow-hidden ring-2 ring-gold/60 shadow-md bg-white relative">
                    <Image
                      src={f.image}
                      alt={f.name}
                      fill
                      sizes="64px"
                      className="object-cover group-hover:scale-110 transition-transform"
                    />
                  </div>
                  <p className="font-semibold text-xs sm:text-sm text-white">
                    {f.name}
                  </p>
                  <span className="text-[10px] text-gold/90 block mt-0.5 flex items-center justify-center gap-1">
                    Lihat Foto <Search className="h-2.5 w-2.5" />
                  </span>
                </motion.button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {active !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
            className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <button
              type="button"
              aria-label="Tutup"
              className="absolute top-5 right-5 text-white/80 hover:text-white p-2 rounded-full bg-white/10 hover:bg-white/20"
              onClick={() => setActive(null)}
            >
              <X className="h-6 w-6" />
            </button>
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="relative aspect-square">
                <Image
                  src={facilities[active].image}
                  alt={facilities[active].name}
                  fill
                  sizes="100vw"
                  className="object-cover"
                />
              </div>
              <div className="p-5 bg-card">
                <h4 className="font-bold text-lg text-foreground">
                  {facilities[active].name}
                </h4>
                <p className="text-muted-foreground text-sm mt-1">
                  {facilities[active].description}
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
