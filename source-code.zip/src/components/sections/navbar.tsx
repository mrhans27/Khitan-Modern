"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { useTheme } from "next-themes";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  CalendarPlus,
  Moon,
  Sun,
  Sparkles,
} from "lucide-react";
import { navLinks, siteConfig } from "@/lib/site";
import { useDaftarStore } from "@/store/ui";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [mounted, setMounted] = React.useState(false);
  const [active, setActive] = React.useState("#beranda");
  const { theme, setTheme } = useTheme();
  const openDaftar = useDaftarStore((s) => s.openWithMethod);

  React.useEffect(() => {
    setMounted(true);
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Scroll spy for active link
  React.useEffect(() => {
    const sections = navLinks
      .map((l) => document.querySelector(l.href))
      .filter(Boolean) as Element[];
    if (sections.length === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(`#${entry.target.id}`);
        });
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  const handleNav = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header className="fixed top-0 inset-x-0 z-50">
      <div
        className={cn(
          "transition-all duration-300",
          scrolled ? "pt-2" : "pt-3"
        )}
      >
        <nav
          className={cn(
            "max-w-7xl mx-auto px-3 sm:px-5 transition-all duration-300",
            scrolled ? "sm:px-4" : "sm:px-6"
          )}
        >
          <div
            className={cn(
              "flex justify-between items-center h-15 md:h-16 px-3 sm:px-4 rounded-2xl transition-all duration-300",
              scrolled
                ? "glass-card-dark shadow-soft"
                : "bg-brand/95 dark:bg-brand/90 backdrop-blur-md shadow-lg shadow-brand/20"
            )}
          >
            {/* Logo */}
            <Link
              href="#beranda"
              onClick={(e) => {
                e.preventDefault();
                handleNav("#beranda");
              }}
              className="flex-shrink-0 flex items-center gap-2.5 group"
            >
              <div className="relative h-10 w-10 md:h-11 md:w-11 rounded-xl bg-white/95 p-0.5 shadow-md ring-1 ring-gold/40 transition-transform group-hover:scale-105 overflow-hidden">
                <Image
                  src="/images/logo.png"
                  alt="Logo Al-Asyraf"
                  fill
                  className="object-cover rounded-xl"
                  sizes="44px"
                  priority
                />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="font-bold text-base md:text-lg text-gold tracking-wide">
                  AL-ASYRAF
                </span>
                <span className="hidden sm:block text-[10px] text-white/75 tracking-wider uppercase font-medium">
                  Rumah Khitan Modern
                </span>
              </div>
            </Link>

            {/* Desktop nav pills */}
            <div className="hidden lg:flex items-center gap-0.5 relative">
              {navLinks.map((link) => {
                const isActive = active === link.href;
                return (
                  <button
                    key={link.href}
                    onClick={() => handleNav(link.href)}
                    className={cn(
                      "relative px-3.5 py-2 text-sm font-medium rounded-xl transition-colors z-10",
                      isActive
                        ? "text-white"
                        : "text-white/80 hover:text-gold"
                    )}
                  >
                    {link.label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-active"
                        className="absolute inset-0 bg-white/12 rounded-xl -z-10"
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                aria-label="Ganti tema"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="hidden sm:flex h-10 w-10 items-center justify-center rounded-xl text-white/80 hover:text-gold hover:bg-white/10 transition-colors"
              >
                {mounted && theme === "dark" ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )}
              </button>

              <button
                type="button"
                onClick={() => openDaftar(null)}
                className="hidden md:inline-flex items-center gap-2 bg-gold hover:bg-gold/90 text-gold-foreground font-semibold px-5 py-2.5 rounded-xl shadow-md transition-all hover:-translate-y-0.5"
              >
                <CalendarPlus className="h-4 w-4" />
                Daftar Online
              </button>

              {/* Mobile toggle */}
              <button
                type="button"
                aria-label="Menu"
                onClick={() => setMobileOpen((v) => !v)}
                className="lg:hidden h-10 w-10 flex items-center justify-center rounded-xl text-white hover:bg-white/10 transition"
              >
                {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </nav>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="lg:hidden fixed inset-x-3 top-[68px] glass-card-dark rounded-2xl p-3 shadow-2xl overflow-hidden"
          >
            <div className="space-y-0.5">
              {navLinks.map((link) => {
                const isActive = active === link.href;
                return (
                  <button
                    key={link.href}
                    onClick={() => handleNav(link.href)}
                    className={cn(
                      "w-full text-left px-4 py-2.5 rounded-xl font-medium transition-colors",
                      isActive
                        ? "bg-gold/20 text-gold"
                        : "text-white/90 hover:bg-white/10"
                    )}
                  >
                    {link.label}
                  </button>
                );
              })}
              <div className="pt-2 mt-1 border-t border-white/10 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    openDaftar(null);
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-gold hover:bg-gold/90 text-gold-foreground font-semibold px-5 py-3 rounded-xl shadow-md"
                >
                  <CalendarPlus className="h-4 w-4" />
                  Daftar Online
                </button>
                <button
                  type="button"
                  aria-label="Ganti tema"
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className="h-12 w-12 flex items-center justify-center rounded-xl text-white border border-white/20 hover:bg-white/10"
                >
                  {mounted && theme === "dark" ? (
                    <Sun className="h-5 w-5" />
                  ) : (
                    <Moon className="h-5 w-5" />
                  )}
                </button>
              </div>
              <p className="text-center text-xs text-white/55 pt-2 flex items-center justify-center gap-1">
                <Sparkles className="h-3 w-3" /> {siteConfig.tagline}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
