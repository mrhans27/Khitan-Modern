"use client";

import { motion } from "framer-motion";
import {
  CalendarCheck,
  Syringe,
  Stethoscope,
  Gift,
  HeartPulse,
  type LucideIcon,
} from "lucide-react";
import { processSteps } from "@/lib/site";
import { SectionHeading } from "./keunggulan";

const iconMap: Record<string, LucideIcon> = {
  CalendarCheck,
  Syringe,
  Stethoscope,
  Gift,
  HeartPulse,
};

export function Proses() {
  return (
    <section
      id="proses"
      className="py-20 md:py-28 bg-background px-4 scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-pattern opacity-50 pointer-events-none" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeading
          eyebrow="Mudah & Cepat"
          title="Alur Khitan Modern"
          subtitle="Lima langkah sederhana untuk pengalaman khitan yang nyaman, aman, dan menyenangkan bagi jagoan Anda."
        />

        <div className="relative">
          {/* Connecting gradient line (desktop) */}
          <div className="hidden lg:block absolute top-12 left-[10%] right-[10%] h-px bg-gradient-to-r from-brand/0 via-brand/40 to-brand/0" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 md:gap-4">
            {processSteps.map((step, i) => {
              const Icon = iconMap[step.icon] ?? CalendarCheck;
              return (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="relative text-center group"
                >
                  <div className="relative inline-flex mb-5">
                    {/* Glow */}
                    <div className="absolute inset-0 rounded-2xl bg-brand/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="relative w-20 h-20 md:w-24 md:h-24 rounded-3xl gradient-brand text-white flex items-center justify-center shadow-lg ring-4 ring-card transition-transform duration-500 group-hover:scale-110">
                      <Icon className="h-9 w-9 md:h-10 md:w-10" />
                    </div>
                    <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-gold text-gold-foreground text-xs font-bold flex items-center justify-center ring-2 ring-card shadow-md">
                      {step.number}
                    </span>
                  </div>
                  <h3 className="font-bold text-lg mb-2 text-foreground">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed text-pretty">
                    {step.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
