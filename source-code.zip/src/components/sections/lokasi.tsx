"use client";

import { motion } from "framer-motion";
import { MapPin, MessageCircle, Clock, Navigation } from "lucide-react";
import { siteConfig, buildWhatsAppUrl } from "@/lib/site";

export function Lokasi() {
  return (
    <section
      id="lokasi"
      className="py-20 md:py-28 bg-muted/40 px-4 border-t border-border scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none mask-fade-b" />
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row gap-10 md:gap-12 relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="md:w-1/2"
        >
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-brand/10 text-brand border border-brand/15 mb-3">
            <span className="h-1.5 w-1.5 rounded-full bg-gold" />
            Kunjungi Kami
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3 leading-tight">
            Lokasi & Kontak
          </h2>
          <div className="h-1 w-16 bg-gradient-gold rounded-full mb-5" />
          <p className="text-muted-foreground mb-7 text-pretty">
            Kami siap menyambut jagoan dan keluarga dengan suasana nyaman dan
            pelayanan ramah.
          </p>

          <div className="space-y-4">
            <InfoRow icon={MapPin} title="Alamat Praktik">
              <p className="text-muted-foreground mt-1 leading-relaxed">
                {siteConfig.address}
              </p>
            </InfoRow>
            <InfoRow icon={MessageCircle} title="WhatsApp / Telepon">
              <a
                href={buildWhatsAppUrl(
                  "Assalamualaikum, saya ingin berkonsultasi tentang khitan."
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-brand font-semibold text-lg transition-colors text-foreground"
              >
                {siteConfig.whatsappDisplay}
              </a>
              <p className="text-sm text-muted-foreground mt-1">
                Siap melayani pertanyaan dan penjadwalan khitan.
              </p>
            </InfoRow>
            <InfoRow icon={Clock} title="Jam Operasional">
              <p className="text-muted-foreground mt-1">{siteConfig.hours}</p>
            </InfoRow>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <a
              href={buildWhatsAppUrl(
                "Halo, saya ingin menjadwalkan khitan di Al-Asyraf."
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex justify-center items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold py-3 px-6 rounded-2xl shadow-lg transition-colors hover:-translate-y-0.5"
            >
              <MessageCircle className="h-5 w-5" />
              Chat WhatsApp Sekarang
            </a>
            <a
              href={siteConfig.mapLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex justify-center items-center gap-2 bg-card border border-border hover:bg-muted text-foreground font-semibold py-3 px-6 rounded-2xl transition-colors"
            >
              <Navigation className="h-5 w-5" />
              Buka di Maps
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="md:w-1/2"
        >
          <div className="rounded-3xl h-80 md:h-full min-h-80 w-full overflow-hidden shadow-soft border border-border relative bg-muted ring-1 ring-brand/5">
            <iframe
              src={siteConfig.mapEmbed}
              width="100%"
              height="100%"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Peta Lokasi Rumah Khitan Al-Asyraf"
              style={{ border: 0 }}
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function InfoRow({
  icon: Icon,
  title,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-4 p-3 rounded-2xl hover:bg-card transition-colors">
      <div className="bg-brand/10 text-brand w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0">
        <Icon className="h-6 w-6" />
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="font-bold text-foreground text-lg">{title}</h4>
        {children}
      </div>
    </div>
  );
}
