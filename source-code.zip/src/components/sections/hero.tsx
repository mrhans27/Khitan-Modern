"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import {
  MessageCircle,
  CalendarPlus,
  ShieldCheck,
  Star,
  ArrowDown,
  Syringe,
  Award,
} from "lucide-react";
import { siteConfig, buildWhatsAppUrl, defaultWaMessage } from "@/lib/site";
import { useDaftarStore } from "@/store/ui";

const trustBadges = [
  { icon: ShieldCheck, label: "Bius Tanpa Suntik" },
  { icon: Award, label: "8+ Tahun Berpengalaman" },
  { icon: Star, label: "1.500+ Jagoan Bahagia" },
];

export function Hero() {
  const openDaftar = useDaftarStore((s) => s.openWithMethod);

  return (
    <section
      id="beranda"
      className="relative min-h-[100svh] flex items-center justify-center overflow-hidden pt-20 md:pt-24"
    >
      {/* Background image + overlay */}
      <div className="absolute inset-0 -z-10">
        <Image
          src="/images/hero-bg.png"
          alt=""
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 hero-overlay" />
        <div className="absolute inset-0 bg-pattern opacity-25" />
      </div>

      {/* Decorative gradient blobs */}
      <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-10 -left-20 w-[28rem] h-[28rem] rounded-full bg-brand/40 blur-[120px] animate-float" />
        <div
          className="absolute bottom-10 -right-20 w-[26rem] h-[26rem] rounded-full bg-gold/25 blur-[120px] animate-float"
          style={{ animationDelay: "-3s" }}
        />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center relative z-10">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-7 flex justify-center"
        >
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-white text-xs sm:text-sm font-medium tracking-wide">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-gold" />
            </span>
            {siteConfig.tagline}
          </span>
        </motion.div>

        {/* Logo with glow ring */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
          className="mb-8 flex justify-center"
        >
          <div className="relative w-40 h-40 sm:w-48 sm:h-48 md:w-56 md:h-56">
            <div className="absolute inset-0 rounded-[2rem] bg-gold/30 blur-2xl animate-pulse" />
            <div className="relative w-full h-full rounded-[2rem] overflow-hidden ring-1 ring-gold/50 shadow-glow-gold bg-white">
              <Image
                src="/images/logo.png"
                alt="Rumah Khitan Al-Asyraf"
                fill
                priority
                sizes="(max-width: 640px) 160px, (max-width: 768px) 192px, 224px"
                className="object-cover"
              />
            </div>
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white mb-5 text-balance leading-[1.05]"
        >
          Rumah Khitan{" "}
          <span className="gradient-text tracking-wide block sm:inline">
            Al-Asyraf
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="text-lg sm:text-xl md:text-2xl text-white/85 font-light mb-3"
        >
          Khitan Modern, Tanpa Trauma, Tanpa Rasa Takut
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="text-base sm:text-lg text-white/70 mb-9 max-w-2xl mx-auto text-pretty"
        >
          Metode Lem, Cincin, dan Jahit dengan teknologi{" "}
          <span className="text-gold font-semibold">bius tanpa suntik</span> —
          nyaman untuk jagoan, tenang untuk orang tua.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center mb-11"
        >
          <a
            href={buildWhatsAppUrl(defaultWaMessage)}
            target="_blank"
            rel="noopener noreferrer"
            className="group w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-white font-semibold py-4 px-8 rounded-2xl text-base shadow-lg shadow-emerald-900/30 transition-all hover:-translate-y-1 hover:shadow-emerald-500/40"
          >
            <MessageCircle className="h-5 w-5 transition-transform group-hover:scale-110" />
            Konsultasi Sekarang
          </a>
          <button
            type="button"
            onClick={() => openDaftar(null)}
            className="group w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gold hover:bg-gold/90 text-gold-foreground font-semibold py-4 px-8 rounded-2xl text-base shadow-lg shadow-gold/30 transition-all hover:-translate-y-1"
          >
            <CalendarPlus className="h-5 w-5 transition-transform group-hover:rotate-12" />
            Daftar Online
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.7 }}
          className="flex flex-wrap items-center justify-center gap-x-5 gap-y-3 text-white/85"
        >
          {trustBadges.map((b) => (
            <span
              key={b.label}
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium"
            >
              <b.icon className="h-4 w-4 text-gold" />
              {b.label}
            </span>
          ))}
        </motion.div>

        {/* Method quick pills */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.85 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-2.5"
        >
          <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl glass-card text-white/90 text-sm">
            <Syringe className="h-4 w-4 text-gold" />
            3 Metode Modern
          </span>
          <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl glass-card text-white/90 text-sm">
            <Star className="h-4 w-4 text-gold" />
            Bonus & Kontrol Gratis
          </span>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.6 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 hidden md:flex flex-col items-center gap-2 text-white/70"
      >
        <span className="text-[10px] tracking-[0.25em] uppercase font-medium">Scroll</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity }}
        >
          <ArrowDown className="h-4 w-4" />
        </motion.div>
      </motion.div>
    </section>
  );
}
