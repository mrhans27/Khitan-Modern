"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { testimonials } from "@/lib/site";
import { SectionHeading } from "./keunggulan";
import { cn } from "@/lib/utils";

const ITEMS_PER_VIEW = { sm: 1, md: 2, lg: 3 };

export function Testimoni() {
  const [index, setIndex] = React.useState(0);
  const [perView, setPerView] = React.useState(3);
  const [auto, setAuto] = React.useState(true);

  React.useEffect(() => {
    const update = () => {
      const w = window.innerWidth;
      setPerView(w >= 1024 ? 3 : w >= 768 ? 2 : 1);
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const maxIndex = Math.max(0, testimonials.length - perView);

  React.useEffect(() => {
    if (index > maxIndex) setIndex(maxIndex);
  }, [maxIndex, index]);

  React.useEffect(() => {
    if (!auto) return;
    const t = setInterval(() => {
      setIndex((i) => (i >= maxIndex ? 0 : i + 1));
    }, 5000);
    return () => clearInterval(t);
  }, [auto, maxIndex]);

  const next = () => {
    setAuto(false);
    setIndex((i) => (i >= maxIndex ? 0 : i + 1));
  };
  const prev = () => {
    setAuto(false);
    setIndex((i) => (i <= 0 ? maxIndex : i - 1));
  };

  return (
    <section
      id="testimoni"
      className="py-20 md:py-28 bg-muted/40 px-4 scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none mask-fade-b" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeading
          eyebrow="Kata Mereka"
          title="Apa Kata Orang Tua Jagoan?"
          subtitle="Kepuasan dan kenyamanan jagoan kami adalah prioritas utama. Berikut pengalaman dari orang tua yang mempercayakan khitan putranya kepada Al-Asyraf."
        />

        <div className="relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${index * (100 / perView)}%)` }}
            >
              {testimonials.map((t, i) => (
                <div
                  key={i}
                  className="flex-shrink-0 px-2.5"
                  style={{ width: `${100 / perView}%` }}
                >
                  <div className="bg-card p-6 md:p-7 rounded-3xl border border-border card-modern card-modern-hover h-full flex flex-col relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-full -mr-8 -mt-8" />
                    <div className="flex items-center justify-between mb-4 relative">
                      <div className="flex gap-1 text-gold">
                        {Array.from({ length: t.rating }).map((_, s) => (
                          <Star key={s} className="h-4 w-4 fill-gold" />
                        ))}
                      </div>
                      <Quote className="h-9 w-9 text-brand/12" />
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-5 italic flex-grow text-pretty">
                      &ldquo;{t.message}&rdquo;
                    </p>
                    <div className="flex items-center gap-3 pt-4 border-t border-border">
                      <div className="w-11 h-11 rounded-2xl gradient-brand text-white flex items-center justify-center font-bold text-base shadow-md">
                        {t.initial}
                      </div>
                      <div>
                        <p className="font-semibold text-foreground text-sm">
                          {t.name}
                        </p>
                        <p className="text-xs text-muted-foreground">{t.role}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3 mt-8">
            <button
              type="button"
              onClick={prev}
              aria-label="Sebelumnya"
              className="h-11 w-11 rounded-2xl bg-card border border-border text-brand hover:bg-brand hover:text-brand-foreground transition flex items-center justify-center shadow-sm"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              {Array.from({ length: maxIndex + 1 }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  aria-label={`Ke slide ${i + 1}`}
                  onClick={() => {
                    setAuto(false);
                    setIndex(i);
                  }}
                  className={cn(
                    "h-2.5 rounded-full transition-all",
                    index === i
                      ? "w-8 bg-brand"
                      : "w-2.5 bg-muted-foreground/30 hover:bg-muted-foreground/50"
                  )}
                />
              ))}
            </div>
            <button
              type="button"
              onClick={next}
              aria-label="Berikutnya"
              className="h-11 w-11 rounded-2xl bg-card border border-border text-brand hover:bg-brand hover:text-brand-foreground transition flex items-center justify-center shadow-sm"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
