"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  MessageCircle,
  X,
  Send,
  Loader2,
  Sparkles,
  Stethoscope,
} from "lucide-react";
import { useChatStore } from "@/store/ui";
import { siteConfig, buildWhatsAppUrl } from "@/lib/site";
import { cn } from "@/lib/utils";

type Msg = { role: "user" | "assistant"; content: string };

const SUGGESTIONS = [
  "Berapa usia minimal khitan?",
  "Info layanan infus vitamin?",
  "Apa beda metode cincin & lem?",
  "Berapa harga khitan?",
];

const WELCOME: Msg = {
  role: "assistant",
  content:
    "Assalamualaikum! 👋 Saya Asisten AI Al-Asyraf. Ada yang bisa saya bantu seputar khitan modern? Anda bisa tanya tentang metode, harga, atau proses pendaftaran.",
};

export function Chatbot() {
  const { open, setOpen, toggle } = useChatStore();
  const [messages, setMessages] = React.useState<Msg[]>([WELCOME]);
  const [input, setInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  // Auto scroll
  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading, open]);

  const send = async (text: string) => {
    const content = text.trim();
    if (!content || loading) return;

    setInput("");
    const nextMessages: Msg[] = [...messages, { role: "user", content }];
    setMessages(nextMessages);
    setLoading(true);

    try {
      const history = nextMessages
        .slice(1) // exclude welcome
        .slice(-8)
        .map((m) => ({ role: m.role, content: m.content }));

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: content, history }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || "Gagal");
      }
      setMessages((m) => [...m, { role: "assistant", content: data.reply }]);
    } catch (err) {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          content:
            "Maaf, saya sedang tidak bisa membalas. Silakan hubungi WhatsApp " +
            siteConfig.whatsappDisplay +
            " untuk bantuan langsung.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating toggle button */}
      <motion.button
        type="button"
        onClick={toggle}
        aria-label="Buka Konsultasi AI"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-4 right-4 z-[90] h-14 w-14 rounded-full bg-brand text-brand-foreground flex items-center justify-center shadow-xl shadow-brand/40 transition-colors md:bottom-6 md:right-6"
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.span
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
            >
              <X className="h-6 w-6" />
            </motion.span>
          ) : (
            <motion.span
              key="open"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              className="relative"
            >
              <MessageCircle className="h-6 w-6" />
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold opacity-75" />
                <span className="relative inline-flex rounded-full h-4 w-4 bg-gold border-2 border-brand" />
              </span>
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-20 right-3 left-3 z-[91] sm:left-auto sm:w-[380px] md:bottom-24 md:right-6"
          >
            <div className="bg-card rounded-2xl shadow-2xl border border-border overflow-hidden flex flex-col h-[540px] max-h-[75vh]">
              {/* Header */}
              <div className="bg-gradient-to-r from-brand to-brand/85 text-white p-4 flex items-center gap-3">
                <div className="relative h-11 w-11 rounded-full bg-white/15 flex items-center justify-center flex-shrink-0">
                  <Stethoscope className="h-6 w-6 text-gold" />
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-400 border-2 border-brand" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-sm flex items-center gap-1.5">
                    Asisten AI Al-Asyraf
                    <Sparkles className="h-3.5 w-3.5 text-gold" />
                  </h3>
                  <p className="text-xs text-white/80">
                    Online &middot; Siap bantu konsultasi
                  </p>
                </div>
                <button
                  type="button"
                  aria-label="Tutup"
                  onClick={() => setOpen(false)}
                  className="h-8 w-8 rounded-full hover:bg-white/15 flex items-center justify-center"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 px-3 py-3" ref={scrollRef as never}>
                <div className="space-y-3 pr-1">
                  {messages.map((m, i) => (
                    <MessageBubble key={i} msg={m} />
                  ))}
                  {loading && (
                    <div className="flex justify-start">
                      <div className="bg-muted rounded-2xl rounded-tl-sm px-4 py-2.5 flex items-center gap-1.5">
                        <span className="h-2 w-2 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:-0.3s]" />
                        <span className="h-2 w-2 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:-0.15s]" />
                        <span className="h-2 w-2 rounded-full bg-muted-foreground/60 animate-bounce" />
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* Suggestions */}
              {messages.length <= 1 && (
                <div className="px-3 pb-2 flex flex-wrap gap-1.5">
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => send(s)}
                      className="text-xs px-3 py-1.5 rounded-full bg-muted hover:bg-brand hover:text-brand-foreground transition-colors border border-border"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}

              {/* Input */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  send(input);
                }}
                className="p-3 border-t border-border flex items-center gap-2"
              >
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Tulis pertanyaan..."
                  disabled={loading}
                  className="flex-1"
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={loading || !input.trim()}
                  className="bg-brand hover:bg-brand/90 h-10 w-10 rounded-full"
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </form>

              {/* Footer link */}
              <div className="px-3 pb-3 -mt-1 text-center">
                <a
                  href={buildWhatsAppUrl(
                    "Halo, saya ingin konsultasi langsung tentang khitan."
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-muted-foreground hover:text-brand transition-colors inline-flex items-center gap-1"
                >
                  <MessageCircle className="h-3 w-3" />
                  Lebih suka chat manusia? Hubungi WhatsApp
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function MessageBubble({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn("flex", isUser ? "justify-end" : "justify-start")}
    >
      <div
        className={cn(
          "max-w-[85%] px-4 py-2.5 text-sm leading-relaxed rounded-2xl",
          isUser
            ? "bg-brand text-brand-foreground rounded-tr-sm"
            : "bg-muted text-foreground rounded-tl-sm"
        )}
      >
        {msg.content.split("\n").map((line, i) => (
          <p key={i} className={i > 0 ? "mt-1" : ""}>
            {line}
          </p>
        ))}
      </div>
    </motion.div>
  );
}
