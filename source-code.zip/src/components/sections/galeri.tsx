"use client";

import * as React from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Images, Video, X, ZoomIn, Loader2 } from "lucide-react";
import { galleryItems } from "@/lib/site";
import { SectionHeading } from "./keunggulan";
import { cn } from "@/lib/utils";

type UploadedMedia = {
  id: string;
  title: string;
  description: string | null;
  tag: string | null;
  type: string;
  url: string;
  thumbUrl: string | null;
};

const videoItems = [
  {
    title: "Penjelasan Metode Cincin",
    description: "Tindakan tanpa jahit & tanpa perban yang menjadi favorit jagoan.",
    thumb: "https://images.pexels.com/photos/7789620/pexels-photo-7789620.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
  {
    title: "Demo Bius Tanpa Suntik",
    description: "Teknologi Free Needle Injection yang membuat anak tetap nyaman.",
    thumb: "https://images.pexels.com/photos/7034123/pexels-photo-7034123.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
  {
    title: "Perawatan Pasca Khitan",
    description: "Panduan lengkap merawat jagoan di rumah hingga sembuh total.",
    thumb: "https://images.pexels.com/photos/8460125/pexels-photo-8460125.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
  },
];

export function Galeri() {
  const [tab, setTab] = React.useState<"foto" | "video">("foto");
  const [active, setActive] = React.useState<string | null>(null);
  const [uploaded, setUploaded] = React.useState<UploadedMedia[]>([]);
  const [loadingMedia, setLoadingMedia] = React.useState(true);

  // Fetch uploaded media (category 'galeri' for this section)
  React.useEffect(() => {
    let alive = true;
    fetch("/api/gallery?category=galeri", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (alive && d.ok) setUploaded(d.items);
      })
      .catch(() => {})
      .finally(() => {
        if (alive) setLoadingMedia(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  // Build merged photo list: uploaded photos first, then static fallbacks
  const uploadedPhotos = uploaded.filter((m) => m.type === "photo");
  const uploadedVideos = uploaded.filter((m) => m.type === "video");
  const hasUserPhoto = uploadedPhotos.length > 0;
  const hasUserVideo = uploadedVideos.length > 0;

  // For "Foto" tab: show uploaded (if any) + static defaults (only if no user uploads yet)
  const fotoItems = hasUserPhoto
    ? uploadedPhotos
    : galleryItems.map((g) => ({
        id: `static-${g.title}`,
        title: g.title,
        description: g.description,
        tag: g.tag,
        type: "photo",
        url: g.image,
        thumbUrl: null,
      }));

  // For "Video" tab: show uploaded videos first + static demo items
  const videoDisplay = [
    ...uploadedVideos.map((v) => ({
      title: v.title,
      description: v.description ?? "",
      thumb: v.thumbUrl ?? v.url,
      url: v.url,
      isUpload: true as const,
    })),
    ...videoItems.map((v) => ({
      title: v.title,
      description: v.description,
      thumb: v.thumb,
      url: null as string | null,
      isUpload: false as const,
    })),
  ];

  return (
    <section
      id="galeri"
      className="py-20 md:py-28 bg-background px-4 scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 gradient-mesh opacity-50 pointer-events-none" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeading
          eyebrow="Dokumentasi"
          title="Galeri & Dokumentasi"
          subtitle="Lihat suasana klinik, momen bahagia jagoan setelah khitan, serta video edukasi metode modern kami."
        />

        {/* Tabs */}
        <div className="flex justify-center mb-10">
          <div className="inline-flex p-1.5 bg-muted rounded-2xl border border-border">
            <button
              type="button"
              onClick={() => setTab("foto")}
              className={cn(
                "px-5 py-2.5 rounded-xl font-semibold transition flex items-center gap-2 text-sm",
                tab === "foto"
                  ? "bg-card text-brand shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Images className="h-4 w-4" /> Foto
            </button>
            <button
              type="button"
              onClick={() => setTab("video")}
              className={cn(
                "px-5 py-2.5 rounded-xl font-semibold transition flex items-center gap-2 text-sm",
                tab === "video"
                  ? "bg-card text-brand shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Video className="h-4 w-4" /> Video
            </button>
          </div>
        </div>

        {tab === "foto" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
            {loadingMedia ? (
              [0, 1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="bg-card rounded-3xl border border-border h-80 animate-pulse"
                />
              ))
            ) : (
              fotoItems.map((item, i) => (
                <motion.button
                  key={item.id}
                  type="button"
                  onClick={() => setActive(item.url)}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.4, delay: (i % 6) * 0.05 }}
                  className="text-left bg-card rounded-3xl overflow-hidden border border-border card-modern card-modern-hover card-hover group"
                >
                  <div className="h-56 overflow-hidden relative">
                    <Image
                      src={item.url}
                      alt={item.title}
                      fill
                      unoptimized={item.url.startsWith("/uploads/")}
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                      className="object-cover group-hover:scale-110 transition duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    {item.tag && (
                      <span className="absolute bottom-3 left-3 glass-card text-white text-xs px-3 py-1 rounded-full font-medium">
                        {item.tag}
                      </span>
                    )}
                    <span className="absolute top-3 right-3 bg-white/95 text-brand p-2 rounded-xl opacity-0 group-hover:opacity-100 transition shadow-md">
                      <ZoomIn className="h-4 w-4" />
                    </span>
                  </div>
                  <div className="p-4">
                    <h4 className="font-bold text-foreground text-lg mb-1">
                      {item.title}
                    </h4>
                    <p className="text-muted-foreground text-sm text-pretty">
                      {item.description}
                    </p>
                  </div>
                </motion.button>
              ))
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
            {loadingMedia ? (
              [0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="bg-card rounded-3xl border border-border h-64 animate-pulse"
                />
              ))
            ) : (
              videoDisplay.map((v, i) => (
                <motion.div
                  key={v.title + i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.4, delay: (i % 6) * 0.05 }}
                  className="bg-card rounded-3xl overflow-hidden border border-border card-modern card-modern-hover card-hover group"
                >
                  <div className="h-44 overflow-hidden relative bg-muted">
                    <Image
                      src={v.thumb}
                      alt={v.title}
                      fill
                      unoptimized={v.thumb.startsWith("/uploads/")}
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                      className="object-cover group-hover:scale-110 transition duration-700"
                    />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                      <div className="w-14 h-14 rounded-full bg-white/95 flex items-center justify-center group-hover:scale-110 transition shadow-lg">
                        <span className="ml-1 w-0 h-0 border-y-[10px] border-y-transparent border-l-[16px] border-l-brand" />
                      </div>
                    </div>
                    {v.isUpload && (
                      <span className="absolute top-3 left-3 bg-brand text-brand-foreground text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">
                        Video Anda
                      </span>
                    )}
                  </div>
                  <div className="p-4">
                    <h4 className="font-bold text-foreground text-lg mb-1">
                      {v.title}
                    </h4>
                    <p className="text-muted-foreground text-sm text-pretty">
                      {v.description}
                    </p>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {active && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
            className="fixed inset-0 z-[100] bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
          >
            <button
              type="button"
              aria-label="Tutup"
              className="absolute top-5 right-5 text-white/80 hover:text-white p-2 rounded-xl bg-white/10 hover:bg-white/20 transition"
              onClick={() => setActive(null)}
            >
              <X className="h-6 w-6" />
            </button>
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-4xl aspect-video rounded-3xl overflow-hidden shadow-2xl ring-1 ring-white/20"
            >
              <Image
                src={active}
                alt="Galeri"
                fill
                sizes="100vw"
                className="object-cover"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
