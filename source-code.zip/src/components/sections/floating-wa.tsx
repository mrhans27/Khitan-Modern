"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X } from "lucide-react";
import { siteConfig, buildWhatsAppUrl, defaultWaMessage } from "@/lib/site";

export function FloatingWhatsApp() {
  const [show, setShow] = React.useState(false);
  const [bubble, setBubble] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    const t = setTimeout(() => setBubble(true), 3000);
    return () => {
      window.removeEventListener("scroll", onScroll);
      clearTimeout(t);
    };
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.6 }}
          className="fixed bottom-4 left-4 z-[89] flex items-center gap-2 md:bottom-6 md:left-6"
        >
          <AnimatePresence>
            {bubble && (
              <motion.div
                initial={{ opacity: 0, x: -10, scale: 0.9 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: -10, scale: 0.9 }}
                className="hidden sm:flex items-center gap-2 bg-card shadow-lg rounded-full pl-4 pr-2 py-1.5 border border-border"
              >
                <span className="text-sm text-foreground whitespace-nowrap">
                  Konsultasi gratis di WhatsApp 👋
                </span>
                <button
                  type="button"
                  aria-label="Tutup"
                  onClick={() => setBubble(false)}
                  className="h-6 w-6 rounded-full hover:bg-muted flex items-center justify-center text-muted-foreground"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
          <a
            href={buildWhatsAppUrl(defaultWaMessage)}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat WhatsApp"
            className="h-14 w-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-xl shadow-emerald-600/40 transition-all hover:scale-105 group relative"
          >
            <MessageCircle className="h-7 w-7 group-hover:rotate-12 transition-transform" />
            <span className="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-20 -z-10" />
          </a>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
