"use client";

import { motion } from "framer-motion";
import { Check, Info, Weight, Car, Star, Sparkles } from "lucide-react";
import { methods } from "@/lib/site";
import { useDaftarStore } from "@/store/ui";
import { SectionHeading } from "./keunggulan";
import { cn } from "@/lib/utils";

export function Metode() {
  const openDaftar = useDaftarStore((s) => s.openWithMethod);

  return (
    <section
      id="metode"
      className="py-20 md:py-28 bg-muted/40 px-4 scroll-mt-20 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-grid opacity-40 pointer-events-none mask-fade-b" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeading
          eyebrow="Harga Transparan"
          title="Pilihan Metode & Biaya"
          subtitle="Pilih metode khitan yang paling sesuai dengan kebutuhan dan kenyamanan putra Anda."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6 max-w-5xl mx-auto items-stretch">
          {methods.map((m, i) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={cn(
                "relative bg-card rounded-3xl overflow-hidden flex flex-col card-hover card-modern",
                m.popular
                  ? "border-2 border-gold card-modern-hover md:-translate-y-4 z-10 ring-gradient"
                  : "border border-border card-modern-hover"
              )}
            >
              {m.badge && (
                <div
                  className={cn(
                    "absolute top-0 right-0 text-white text-[11px] font-bold px-4 py-1.5 rounded-bl-2xl uppercase tracking-wider flex items-center gap-1 z-20",
                    m.popular ? "bg-gold" : "bg-brand"
                  )}
                >
                  {m.popular && <Star className="h-3 w-3 fill-white" />}
                  {m.badge}
                </div>
              )}

              {/* Gradient top strip */}
              <div
                className={cn(
                  "h-1.5 w-full",
                  m.popular ? "bg-gradient-gold" : "bg-gradient-brand"
                )}
              />

              <div className="p-7 md:p-8 flex-grow">
                <h3 className="text-2xl font-bold text-foreground mb-2 mt-3">
                  {m.name}
                </h3>
                <p className="text-muted-foreground mb-6 text-sm text-pretty">
                  {m.tagline}
                </p>
                <div className="text-4xl font-extrabold text-foreground mb-1 leading-none">
                  {m.priceLabel.split(".")[0]}
                  <span className="text-lg text-muted-foreground font-medium">
                    .{m.priceLabel.split(".").slice(1).join(".")}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mb-6">
                  sekali tindakan
                </p>

                <div className="h-px w-full bg-border mb-5" />

                <ul className="space-y-3 mb-2">
                  {m.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5">
                      <span
                        className={cn(
                          "mt-0.5 flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center",
                          m.popular
                            ? "bg-gold/15 text-gold"
                            : "bg-brand/10 text-brand"
                        )}
                      >
                        <Check className="h-3 w-3" strokeWidth={3} />
                      </span>
                      <span className="text-foreground/80 text-sm">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-6 pt-0 mt-auto">
                <button
                  type="button"
                  onClick={() => openDaftar(m.id)}
                  className={cn(
                    "block w-full text-center font-semibold py-3 rounded-2xl transition-all",
                    m.popular
                      ? "bg-gradient-gold hover:opacity-90 text-gold-foreground shadow-md hover:-translate-y-0.5"
                      : "bg-card text-brand border border-brand/30 hover:bg-brand hover:text-brand-foreground"
                  )}
                >
                  Pilih Paket
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional services */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-4xl mx-auto mt-8 bg-emerald-50 dark:bg-emerald-500/10 p-6 rounded-3xl border border-emerald-100 dark:border-emerald-500/20"
        >
          <h4 className="font-bold text-emerald-800 dark:text-emerald-400 mb-4 flex items-center gap-2">
            <Info className="h-5 w-5" /> Layanan Tambahan
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-start gap-3 bg-card p-4 rounded-2xl border border-border card-modern">
              <div className="bg-emerald-100 dark:bg-emerald-500/15 p-2.5 rounded-xl text-emerald-600 dark:text-emerald-400 flex-shrink-0">
                <Weight className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold text-foreground">
                  Sunat Gemuk & Repair
                </p>
                <p className="text-sm text-muted-foreground">
                  Terdapat tambahan biaya disesuaikan dengan tingkat kesulitan
                  tindakan.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 bg-card p-4 rounded-2xl border border-border card-modern">
              <div className="bg-emerald-100 dark:bg-emerald-500/15 p-2.5 rounded-xl text-emerald-600 dark:text-emerald-400 flex-shrink-0">
                <Car className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold text-foreground">
                  Layanan Panggilan (Home Service)
                </p>
                <p className="text-sm text-muted-foreground">
                  Khitan di rumah Anda. Tambahan biaya Rp 50.000 (menyesuaikan
                  jarak tempuh).
                </p>
              </div>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-400">
            <Sparkles className="h-4 w-4" />
            Semua metode sudah termasuk bius tanpa suntik, alat steril, dan
            fasilitas gratis.
          </div>
        </motion.div>
      </div>
    </section>
  );
}
