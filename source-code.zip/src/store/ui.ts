import { create } from "zustand";

type DaftarState = {
  open: boolean;
  preselectMethod: string | null;
  setOpen: (open: boolean) => void;
  openWithMethod: (method: string | null) => void;
  toggle: () => void;
};

export const useDaftarStore = create<DaftarState>((set) => ({
  open: false,
  preselectMethod: null,
  setOpen: (open) => set({ open }),
  openWithMethod: (method) => set({ open: true, preselectMethod: method }),
  toggle: () => set((s) => ({ open: !s.open })),
}));

type ChatState = {
  open: boolean;
  setOpen: (open: boolean) => void;
  toggle: () => void;
};

export const useChatStore = create<ChatState>((set) => ({
  open: false,
  setOpen: (open) => set({ open }),
  toggle: () => set((s) => ({ open: !s.open })),
}));

type AdminState = {
  open: boolean;
  setOpen: (open: boolean) => void;
  toggle: () => void;
};

export const useAdminStore = create<AdminState>((set) => ({
  open: false,
  setOpen: (open) => set({ open }),
  toggle: () => set((s) => ({ open: !s.open })),
}));
