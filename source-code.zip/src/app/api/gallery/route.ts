import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET — list all gallery media (public)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category"); // 'galeri' | 'dokumentasi'
    const where = category ? { category } : {};
    const items = await db.galleryMedia.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 200,
    });
    return NextResponse.json({ ok: true, items });
  } catch (e) {
    console.error("[API /gallery GET]", e);
    return NextResponse.json({ ok: false, error: "Gagal memuat galeri" }, { status: 500 });
  }
}
