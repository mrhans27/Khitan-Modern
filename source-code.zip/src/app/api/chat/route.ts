import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const SYSTEM_PROMPT = `Anda adalah Asisten Konsultasi AI "Al-Asyraf" untuk Rumah Khitan Al-Asyraf, pusat khitan modern terpercaya di Situbondo, Indonesia.

Tugas Anda: membantu orang tua yang berkonsultasi seputar layanan khitan modern dengan ramah, informatif, dan profesional dalam Bahasa Indonesia.

INFORMASI KLINIK:
- Nama: Rumah Khitan Al-Asyraf
- Lokasi: Belakang Toko Ringgit Lama, ke utara Taman Kota Asembagus, Situbondo
- WhatsApp: 0822-5708-9393
- Jam operasional: Setiap hari 08.00-20.00 WIB

METODE & HARGA:
1. Metode Jahit - Rp 750.000 (bius tanpa suntik, hasil rapi & estetis)
2. Metode Cincin/Ring - Rp 1.150.000 (TERPOPULER: bius tanpa suntik, tanpa jahit & tanpa perban, bisa langsung mandi & beraktivitas)
3. Metode Lem - Rp 1.200.000 (PREMIUM: bius tanpa suntik, tanpa alat menempel, penyembuhan lebih cepat)

LAYANAN TAMBAHAN:
- Sunat Gemuk & Repair: tambahan biaya disesuaikan tingkat kesulitan
- Home service (panggilan ke rumah): tambahan Rp 50.000 menyesuaikan jarak
- INFUS VITAMIN HOMECARE (LAYANAN BARU): pemasangan infus vitamin langsung di rumah pasien oleh tenaga medis bersertifikat. Paket:
  • Infus Vitamin C standar (1-3 gram) — Rp 250.000 (±30 menit)
  • Infus Vitamin C High Dose (5-10 gram) — Rp 450.000 (±45 menit) [TERPOPULER]
  • Infus Vitamin Cocktail (Vitamin C + B Complex + Mineral) — Rp 550.000 (±45-60 menit)
  • Imun Booster Pack (Vitamin C High Dose + B Complex + Zinc) — Rp 750.000 (±60 menit) [PAKET LENGKAP]
  Area layanan infus home service: Asembagus, Banyuputih, Kapongan & sekitar Situbondo. Untuk lokasi lebih jauh konsultasi via WhatsApp. Pemesanan bisa lewat website (section "Infus Vitamin") atau WhatsApp.

FASILITAS GRATIS setiap khitan: Mobil Remot, Celana Khitan, Sertifikat, Tas Sunat, Obat Rawat Jalan, Kontrol Gratis.

KEUNGGULAN:
- Bius tanpa suntik (Free Needle Injection) - anak tidak takut jarum
- Metode cincin/lem tanpa jahit & tanpa perban
- Anak bisa langsung aktivitas normal
- Kontrol pasca khitan gratis sampai sembuh
- Usia layanan: 2 tahun hingga dewasa

INFO PENTING:
- Anak TIDAK perlu puasa sebelum khitan, justru disarankan sudah makan
- Proses tindakan 10-15 menit, total di klinik 30-45 menit
- Penyembuhan: Cincin/Lem 7-10 hari, Jahit 10-14 hari

ATURAN JAWABAN:
- Selalu ramah, hangat, dan menenangkan (banyak ortu cemas)
- Jawab ringkas, jelas, gunakan poin bila perlu
- Jika ditanya hal di luar layanan khitan, arahkan kembali ke topik khitan atau sarankan hubungi WhatsApp
- Selalu anjurkan pendaftaran online atau konsultasi via WhatsApp 0822-5708-9393 untuk penjadwalan
- JANGAN memberikan diagnosis medis spesifik atau menjamin kesembuhan
- Gunakan Bahasa Indonesia yang baik, boleh sedikit kasual/akrab`;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { message, history } = body as {
      message?: string;
      history?: { role: string; content: string }[];
    };

    if (!message || typeof message !== "string" || message.trim().length === 0) {
      return NextResponse.json(
        { ok: false, error: "Pesan tidak boleh kosong" },
        { status: 400 }
      );
    }

    // Build conversation messages
    const priorMessages = Array.isArray(history)
      ? history
          .filter((m) => m && (m.role === "user" || m.role === "assistant") && m.content)
          .slice(-8)
          .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }))
      : [];

    const messages = [
      { role: "assistant" as const, content: SYSTEM_PROMPT },
      ...priorMessages,
      { role: "user" as const, content: message },
    ];

    // Lazy import to keep startup fast
    const ZAIModule = await import("z-ai-web-dev-sdk");
    const ZAI = ZAIModule.default;
    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });

    const reply = completion.choices?.[0]?.message?.content?.trim();

    if (!reply) {
      return NextResponse.json(
        { ok: false, error: "Maaf, saya tidak dapat membalas saat ini. Silakan hubungi WhatsApp 0822-5708-9393." },
        { status: 502 }
      );
    }

    return NextResponse.json({ ok: true, reply });
  } catch (e) {
    console.error("[API /chat] error", e);
    const message = e instanceof Error ? e.message : "Kesalahan server";
    return NextResponse.json(
      {
        ok: false,
        error: "Maaf, asisten AI sedang tidak tersedia. Silakan hubungi WhatsApp 0822-5708-9393.",
        detail: message,
      },
      { status: 500 }
    );
  }
}
