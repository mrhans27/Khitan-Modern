import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET — list approved reviews (public)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const limit = Number(searchParams.get("limit") ?? 100);
    const reviews = await db.review.findMany({
      where: { approved: true },
      orderBy: { createdAt: "desc" },
      take: Math.min(Math.max(limit, 1), 500),
    });
    const avg =
      reviews.length > 0
        ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
        : 0;
    return NextResponse.json({
      ok: true,
      reviews,
      average: Math.round(avg * 10) / 10,
      total: reviews.length,
    });
  } catch (e) {
    console.error("[API /reviews GET]", e);
    return NextResponse.json({ ok: false, error: "Gagal memuat ulasan" }, { status: 500 });
  }
}

// POST — submit a new review (pending approval)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, role, rating, comment, service } = body ?? {};

    if (!name || typeof name !== "string" || name.trim().length < 2) {
      return NextResponse.json(
        { ok: false, error: "Nama wajib diisi" },
        { status: 400 }
      );
    }
    const r = Number(rating);
    if (!Number.isFinite(r) || r < 1 || r > 5) {
      return NextResponse.json(
        { ok: false, error: "Rating harus 1-5" },
        { status: 400 }
      );
    }
    if (!comment || typeof comment !== "string" || comment.trim().length < 5) {
      return NextResponse.json(
        { ok: false, error: "Ulasan minimal 5 karakter" },
        { status: 400 }
      );
    }

    const review = await db.review.create({
      data: {
        name: name.trim().slice(0, 80),
        role:
          typeof role === "string" && role.trim()
            ? role.trim().slice(0, 80)
            : "Pasien / Pelanggan",
        rating: Math.round(r),
        comment: comment.trim().slice(0, 800),
        service:
          typeof service === "string" && service.trim()
            ? service.trim().slice(0, 100)
            : null,
        approved: false,
      },
    });

    return NextResponse.json({
      ok: true,
      id: review.id,
      message:
        "Terima kasih! Ulasan Anda berhasil dikirim dan akan tampil setelah disetujui admin.",
    });
  } catch (e) {
    console.error("[API /reviews POST]", e);
    const message = e instanceof Error ? e.message : "Terjadi kesalahan";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
