import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function checkAuth(req: NextRequest) {
  const auth = req.headers.get("authorization");
  const key = process.env.ADMIN_KEY;
  if (!key) return false;
  return auth === `Bearer ${key}`;
}

// GET — admin: list ALL reviews (pending + approved)
export async function GET(req: NextRequest) {
  if (!checkAuth(req)) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  try {
    const items = await db.review.findMany({
      orderBy: { createdAt: "desc" },
      take: 500,
    });
    return NextResponse.json({ ok: true, items });
  } catch (e) {
    console.error("[admin/reviews GET]", e);
    return NextResponse.json({ ok: false, error: "Gagal memuat" }, { status: 500 });
  }
}

// PATCH — admin: approve / reject / edit a review
export async function PATCH(req: NextRequest) {
  if (!checkAuth(req)) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  try {
    const body = await req.json();
    const { id, approved, rating, comment } = body ?? {};
    if (!id) {
      return NextResponse.json({ ok: false, error: "ID wajib" }, { status: 400 });
    }
    const data: Record<string, unknown> = {};
    if (typeof approved === "boolean") data.approved = approved;
    if (typeof rating === "number" && rating >= 1 && rating <= 5) data.rating = Math.round(rating);
    if (typeof comment === "string") data.comment = comment.trim().slice(0, 800);
    const updated = await db.review.update({ where: { id }, data });
    return NextResponse.json({ ok: true, review: updated });
  } catch (e) {
    console.error("[admin/reviews PATCH]", e);
    return NextResponse.json({ ok: false, error: "Gagal update" }, { status: 500 });
  }
}

// DELETE — admin: delete a review
export async function DELETE(req: NextRequest) {
  if (!checkAuth(req)) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ ok: false, error: "ID wajib" }, { status: 400 });
    }
    await db.review.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("[admin/reviews DELETE]", e);
    return NextResponse.json({ ok: false, error: "Gagal hapus" }, { status: 500 });
  }
}
