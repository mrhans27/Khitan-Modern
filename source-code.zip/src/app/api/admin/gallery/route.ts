import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import fs from "fs/promises";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
const MAX_SIZE = 25 * 1024 * 1024; // 25MB
const ALLOWED_IMG = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
const ALLOWED_VID = [".mp4", ".webm", ".mov", ".m4v"];

function checkAuth(req: NextRequest) {
  const auth = req.headers.get("authorization");
  const key = process.env.ADMIN_KEY;
  if (!key) return false;
  return auth === `Bearer ${key}`;
}

// GET — admin: list ALL gallery media (incl. unapproved-style fields) for management
export async function GET(req: NextRequest) {
  if (!checkAuth(req)) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  try {
    const items = await db.galleryMedia.findMany({
      orderBy: { createdAt: "desc" },
      take: 500,
    });
    return NextResponse.json({ ok: true, items });
  } catch (e) {
    console.error("[admin/gallery GET]", e);
    return NextResponse.json({ ok: false, error: "Gagal memuat data" }, { status: 500 });
  }
}

// POST — admin: create gallery media entry (metadata only, URL provided)
export async function POST(req: NextRequest) {
  if (!checkAuth(req)) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  try {
    const body = await req.json();
    const { title, description, tag, type, url, thumbUrl, category } = body ?? {};

    if (!title || typeof title !== "string" || title.trim().length < 2) {
      return NextResponse.json({ ok: false, error: "Judul wajib diisi" }, { status: 400 });
    }
    if (!url || typeof url !== "string") {
      return NextResponse.json({ ok: false, error: "URL media wajib diisi" }, { status: 400 });
    }

    const media = await db.galleryMedia.create({
      data: {
        title: title.trim().slice(0, 120),
        description:
          typeof description === "string" ? description.trim().slice(0, 400) : null,
        tag: typeof tag === "string" && tag.trim() ? tag.trim().slice(0, 60) : null,
        type: type === "video" ? "video" : "photo",
        url: url.trim(),
        thumbUrl:
          typeof thumbUrl === "string" && thumbUrl.trim() ? thumbUrl.trim() : null,
        category: category === "dokumentasi" ? "dokumentasi" : "galeri",
      },
    });

    return NextResponse.json({ ok: true, id: media.id });
  } catch (e) {
    console.error("[admin/gallery POST]", e);
    const message = e instanceof Error ? e.message : "Terjadi kesalahan";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

// DELETE — admin: delete a gallery media entry (and its file if local upload)
export async function DELETE(req: NextRequest) {
  if (!checkAuth(req)) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ ok: false, error: "ID wajib diisi" }, { status: 400 });
    }
    const item = await db.galleryMedia.findUnique({ where: { id } });
    if (!item) {
      return NextResponse.json({ ok: false, error: "Tidak ditemukan" }, { status: 404 });
    }

    // Delete local file if stored under /uploads
    if (item.url.startsWith("/uploads/")) {
      const filePath = path.join(process.cwd(), "public", item.url);
      try {
        await fs.unlink(filePath);
      } catch {
        /* ignore missing file */
      }
      if (item.thumbUrl && item.thumbUrl.startsWith("/uploads/")) {
        try {
          await fs.unlink(path.join(process.cwd(), "public", item.thumbUrl));
        } catch {
          /* ignore */
        }
      }
    }

    await db.galleryMedia.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("[admin/gallery DELETE]", e);
    return NextResponse.json({ ok: false, error: "Gagal menghapus" }, { status: 500 });
  }
}
