import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const validMethods = ["jahit", "cincin", "lem"];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      parentName,
      parentPhone,
      childName,
      childAge,
      method,
      homeService,
      address,
      preferredDate,
      notes,
    } = body;

    // Validation
    if (!parentName || typeof parentName !== "string" || parentName.trim().length < 2) {
      return NextResponse.json(
        { ok: false, error: "Nama orang tua wajib diisi" },
        { status: 400 }
      );
    }
    if (!parentPhone || typeof parentPhone !== "string" || parentPhone.length < 8) {
      return NextResponse.json(
        { ok: false, error: "Nomor WhatsApp orang tua tidak valid" },
        { status: 400 }
      );
    }
    if (!childName || typeof childName !== "string" || childName.trim().length < 2) {
      return NextResponse.json(
        { ok: false, error: "Nama jagoan wajib diisi" },
        { status: 400 }
      );
    }
    const age = Number(childAge);
    if (!Number.isFinite(age) || age < 0 || age > 100) {
      return NextResponse.json(
        { ok: false, error: "Usia jagoan tidak valid" },
        { status: 400 }
      );
    }
    if (!method || !validMethods.includes(method)) {
      return NextResponse.json(
        { ok: false, error: "Metode khitan tidak valid" },
        { status: 400 }
      );
    }

    // Sanitize phone
    const cleanPhone = parentPhone.replace(/[^\d+]/g, "");

    const registration = await db.registration.create({
      data: {
        parentName: parentName.trim(),
        parentPhone: cleanPhone,
        childName: childName.trim(),
        childAge: age,
        method,
        homeService: Boolean(homeService),
        address: typeof address === "string" ? address.trim() : null,
        preferredDate: typeof preferredDate === "string" ? preferredDate : null,
        notes: typeof notes === "string" ? notes.trim() : null,
        status: "pending",
      },
    });

    return NextResponse.json({ ok: true, id: registration.id });
  } catch (e) {
    console.error("[API /daftar] error", e);
    const message = e instanceof Error ? e.message : "Terjadi kesalahan server";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function GET() {
  try {
    const total = await db.registration.count();
    return NextResponse.json({ ok: true, total });
  } catch (e) {
    console.error("[API /daftar GET] error", e);
    return NextResponse.json({ ok: false, error: "Gagal mengambil data" }, { status: 500 });
  }
}
