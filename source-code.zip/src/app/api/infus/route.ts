import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const validPackages = [
  "vitamin-c",
  "vitamin-c-high",
  "cocktail",
  "imun-booster",
];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { patientName, patientPhone, package: pkg, address, preferredDate, notes } =
      body ?? {};

    if (
      !patientName ||
      typeof patientName !== "string" ||
      patientName.trim().length < 2
    ) {
      return NextResponse.json(
        { ok: false, error: "Nama pasien wajib diisi" },
        { status: 400 }
      );
    }
    if (
      !patientPhone ||
      typeof patientPhone !== "string" ||
      patientPhone.replace(/[^\d]/g, "").length < 9
    ) {
      return NextResponse.json(
        { ok: false, error: "Nomor WhatsApp pasien tidak valid" },
        { status: 400 }
      );
    }
    if (!pkg || !validPackages.includes(pkg)) {
      return NextResponse.json(
        { ok: false, error: "Paket infus tidak valid" },
        { status: 400 }
      );
    }
    if (!address || typeof address !== "string" || address.trim().length < 5) {
      return NextResponse.json(
        { ok: false, error: "Alamat wajib diisi untuk layanan homecare" },
        { status: 400 }
      );
    }

    const cleanPhone = patientPhone.replace(/[^\d+]/g, "");

    const order = await db.infusOrder.create({
      data: {
        patientName: patientName.trim(),
        patientPhone: cleanPhone,
        package: pkg,
        address: address.trim(),
        preferredDate: typeof preferredDate === "string" ? preferredDate : null,
        notes: typeof notes === "string" ? notes.trim() : null,
        status: "pending",
      },
    });

    return NextResponse.json({ ok: true, id: order.id });
  } catch (e) {
    console.error("[API /infus] error", e);
    const message = e instanceof Error ? e.message : "Terjadi kesalahan server";
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}

export async function GET() {
  try {
    const total = await db.infusOrder.count();
    return NextResponse.json({ ok: true, total });
  } catch (e) {
    console.error("[API /infus GET] error", e);
    return NextResponse.json(
      { ok: false, error: "Gagal mengambil data" },
      { status: 500 }
    );
  }
}
