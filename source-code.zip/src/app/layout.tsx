import type { Metadata } from "next";
import { Poppins, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { QueryProvider } from "@/components/query-provider";

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
});

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-plus-jakarta",
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Rumah Khitan Al-Asyraf - Khitan Modern Terpercaya di Situbondo",
  description:
    "Rumah Khitan Al-Asyraf - Pusat Khitan Modern Terpercaya di Situbondo. Metode Lem, Cincin, dan Jahit dengan bius tanpa suntik. Hadiah & kontrol gratis.",
  keywords: [
    "khitan modern",
    "sunat",
    "Situbondo",
    "khitan anak",
    "metode cincin",
    "metode lem",
    "Al-Asyraf",
  ],
  authors: [{ name: "Rumah Khitan Al-Asyraf" }],
  icons: {
    icon: "/images/logo.png",
  },
  openGraph: {
    title: "Rumah Khitan Al-Asyraf - Khitan Modern Situbondo",
    description:
      "Pusat Khitan Modern Terpercaya di Situbondo. Metode Lem, Cincin, dan Jahit dengan bius tanpa suntik.",
    url: "https://rumah-khitan-al-asyr.com",
    siteName: "Rumah Khitan Al-Asyraf",
    type: "website",
    images: [{ url: "/images/og-cover.png", width: 1200, height: 675 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Rumah Khitan Al-Asyraf",
    description: "Khitan Modern Terpercaya di Situbondo",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${poppins.variable} ${jakarta.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange
        >
          <QueryProvider>{children}</QueryProvider>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
