import { Navbar } from "@/components/sections/navbar";
import { Hero } from "@/components/sections/hero";
import { Keunggulan } from "@/components/sections/keunggulan";
import { Metode } from "@/components/sections/metode";
import { Infus } from "@/components/sections/infus";
import { Proses } from "@/components/sections/proses";
import { Stats } from "@/components/sections/stats";
import { Galeri } from "@/components/sections/galeri";
import { Fasilitas } from "@/components/sections/fasilitas";
import { Testimoni } from "@/components/sections/testimoni";
import { Ulasan } from "@/components/sections/ulasan";
import { Faq } from "@/components/sections/faq";
import { Lokasi } from "@/components/sections/lokasi";
import { Footer } from "@/components/sections/footer";
import { DaftarModal } from "@/components/sections/daftar-modal";
import { Chatbot } from "@/components/sections/chatbot";
import { FloatingWhatsApp } from "@/components/sections/floating-wa";
import { AdminPanelProvider } from "@/components/sections/admin-panel-provider";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Keunggulan />
        <Stats />
        <Metode />
        <Infus />
        <Proses />
        <Galeri />
        <Fasilitas />
        <Testimoni />
        <Ulasan />
        <Faq />
        <Lokasi />
      </main>
      <Footer />

      {/* Interactive overlays */}
      <DaftarModal />
      <Chatbot />
      <FloatingWhatsApp />
      <AdminPanelProvider />
    </div>
  );
}
