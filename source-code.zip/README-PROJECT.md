# Rumah Khitan Al-Asyraf — Website

Website Rumah Khitan Al-Asyraf (Situbondo) dengan fitur:
- Pendaftaran khitan online (3 metode: Jahit, Cincin, Lem)
- Layanan Homecare Infus Vitamin (4 paket)
- AI Chatbot konsultasi (z-ai-web-dev-sdk)
- Sistem ulasan & rating pelanggan (dengan approval admin)
- Galeri foto/video yang dapat dikelola admin (upload tanpa edit kode)
- Dark mode, desain modern (glassmorphism, gradient mesh)

## Tech Stack
- Next.js 16 (App Router) + TypeScript
- Tailwind CSS 4 + shadcn/ui
- Prisma ORM + SQLite
- Framer Motion (animasi)
- Zustand (state management)
- z-ai-web-dev-sdk (AI chatbot)

## Cara Menjalankan

1. **Install dependencies:**
   ```bash
   bun install
   # atau: npm install
   ```

2. **Setup environment (.env):**
   ```
   DATABASE_URL=file:./db/custom.db
   ADMIN_KEY=alasyraf2026admin
   ```
   (Ganti ADMIN_KEY dengan kunci rahasia Anda sendiri)

3. **Setup database:**
   ```bash
   bun run db:push
   ```

4. **Jalankan dev server:**
   ```bash
   bun run dev
   ```
   Buka http://localhost:3000

## Struktur Proyek

```
src/
├── app/
│   ├── api/
│   │   ├── daftar/         # Pendaftaran khitan (POST)
│   │   ├── infus/          # Pemesanan infus vitamin (POST)
│   │   ├── chat/           # AI chatbot (POST → z-ai LLM)
│   │   ├── reviews/        # Ulasan publik (GET/POST)
│   │   ├── gallery/        # Galeri publik (GET)
│   │   └── admin/
│   │       ├── upload/     # Upload file (POST)
│   │       ├── gallery/    # CRUD galeri (GET/POST/DELETE)
│   │       └── reviews/    # Kelola ulasan (GET/PATCH/DELETE)
│   ├── globals.css         # Design system (tema green/gold)
│   ├── layout.tsx          # Root layout (font, providers)
│   └── page.tsx            # Halaman utama (semua section)
├── components/
│   ├── sections/           # Semua komponen section website
│   │   ├── navbar.tsx, hero.tsx, keunggulan.tsx, metode.tsx
│   │   ├── infus.tsx, proses.tsx, stats.tsx, galeri.tsx
│   │   ├── fasilitas.tsx, testimoni.tsx, ulasan.tsx
│   │   ├── faq.tsx, lokasi.tsx, footer.tsx
│   │   ├── daftar-modal.tsx, infus-modal.tsx
│   │   ├── chatbot.tsx, floating-wa.tsx
│   │   └── admin-panel.tsx, admin-panel-provider.tsx
│   ├── ui/                 # Komponen shadcn/ui
│   ├── theme-provider.tsx
│   └── query-provider.tsx
├── lib/
│   ├── site.ts             # Konfigurasi & data situs (metode, harga, FAQ, dll)
│   ├── db.ts               # Prisma client
│   └── utils.ts
├── store/
│   └── ui.ts               # Zustand stores (modal daftar, chatbot, admin)
prisma/
└── schema.prisma           # Skema database (Registration, InfusOrder, Review, GalleryMedia)
public/
└── images/                 # Logo & gambar (di-generate AI)
```

## Akses Panel Admin

- **Shortcut keyboard:** `Ctrl + Shift + A`
- **Atau** klik link "Admin" kecil di paling bawah footer
- **Kunci admin:** `alasyraf2026admin` (ubah di .env)

Di panel admin Anda bisa:
- Upload foto/video ke galeri (langsung tampil di website)
- Setujui / tolak / hapus ulasan pelanggan

## Database Models (Prisma)

- **Registration** — pendaftaran khitan
- **InfusOrder** — pemesanan infus vitamin
- **Review** — ulasan pelanggan (pending → approved)
- **GalleryMedia** — media galeri (foto/video, kategori galeri/dokumentasi)
- **ChatMessage** — riwayat chat (opsional)

## Catatan

- Database SQLite disimpan di `db/custom.db` (auto-created saat `db:push`)
- File upload disimpan di `public/uploads/`
- Gambar default memakai Pexels CDN (perlu internet)
- AI chatbot butuh `z-ai-web-dev-sdk` (sudah terinstall)
- Konfigurasi `next.config.ts` sudah allow domain: `images.pexels.com`, `i.postimg.cc`

## Build Production

```bash
bun run build
bun run start
```

© Rumah Khitan Al-Asyraf — Situbondo
